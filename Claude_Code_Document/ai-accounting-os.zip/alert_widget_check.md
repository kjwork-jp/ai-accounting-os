# Payment Alert Widget Check - Final

Widget is fully functional with 7 payment items displayed:
1. 有限会社佐藤製作所 - 2日超過 (red, overdue) - ¥165,000
2. 山田商事株式会社 - 本日 (amber, urgent) - ¥275,000
3. 株式会社テクノソリューションズ - あと1日 (amber, urgent) - ¥550,000
4. 合同会社クラウドワークス - あと3日 (amber, urgent) - ¥1,320,000
5. （株）テクノソリューション - あと5日 (blue) - ¥990,000
6. 株式会社デジタルメディア - あと7日 (yellow, warning) - ¥880,000
7. グローバルIT株式会社 - あと10日 (blue) - ¥440,000

Color coding works correctly:
- Red: overdue items
- Amber: due within 3 days
- Yellow: due within 7 days
- Blue: due within 14 days

Badge shows "7件" count. All data is correctly displayed.
