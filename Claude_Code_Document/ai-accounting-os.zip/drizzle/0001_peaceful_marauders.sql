CREATE TABLE `ai_suggestions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`documentId` int NOT NULL,
	`rank` int NOT NULL,
	`confidence` decimal(3,2) NOT NULL,
	`suggestion` json NOT NULL,
	`reason` text,
	`accepted` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ai_suggestions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `approvals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`approvalType` enum('payment','expense','reimbursement','partner_change') NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`amount` decimal(15,2),
	`partnerId` int,
	`documentId` int,
	`status` enum('pending','approved','rejected','returned') NOT NULL DEFAULT 'pending',
	`riskScore` int,
	`riskReasons` json,
	`aiReview` json,
	`requestedBy` int,
	`approvedBy` int,
	`approvedAt` timestamp,
	`comment` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `approvals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`action` varchar(50) NOT NULL,
	`entityType` varchar(50) NOT NULL,
	`entityId` int,
	`details` json,
	`aiInput` json,
	`aiOutput` json,
	`aiConfidence` decimal(3,2),
	`userId` int,
	`userName` varchar(255),
	`ipAddress` varchar(45),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `audit_logs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `documents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`fileName` varchar(500) NOT NULL,
	`fileUrl` text NOT NULL,
	`fileKey` varchar(500) NOT NULL,
	`fileHash` varchar(64),
	`mimeType` varchar(100),
	`fileSize` int,
	`documentType` enum('invoice','receipt','delivery_note','quotation','contract','bank_statement','credit_card','other') NOT NULL DEFAULT 'other',
	`status` enum('uploaded','processing','extracted','verified','error') NOT NULL DEFAULT 'uploaded',
	`partnerId` int,
	`documentDate` timestamp,
	`amount` decimal(15,2),
	`taxAmount` decimal(15,2),
	`taxRate` varchar(10),
	`registrationNumber` varchar(20),
	`extractedData` json,
	`aiConfidence` decimal(3,2),
	`uploadedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `documents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceNumber` varchar(50) NOT NULL,
	`invoiceType` enum('issued','received') NOT NULL,
	`orderId` int,
	`partnerId` int,
	`issueDate` timestamp NOT NULL,
	`dueDate` timestamp,
	`status` enum('draft','issued','sent','paid','overdue','cancelled') NOT NULL DEFAULT 'draft',
	`subtotal` decimal(15,2),
	`taxAmount` decimal(15,2),
	`totalAmount` decimal(15,2),
	`registrationNumber` varchar(20),
	`invoiceChecks` json,
	`fileUrl` text,
	`fileKey` varchar(500),
	`journalEntryId` int,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `journal_entries` (
	`id` int AUTO_INCREMENT NOT NULL,
	`entryDate` timestamp NOT NULL,
	`description` text,
	`status` enum('draft','confirmed','cancelled') NOT NULL DEFAULT 'draft',
	`documentId` int,
	`partnerId` int,
	`totalAmount` decimal(15,2),
	`aiGenerated` boolean DEFAULT false,
	`aiConfidence` decimal(3,2),
	`confirmedBy` int,
	`confirmedAt` timestamp,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `journal_entries_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `journal_lines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`journalEntryId` int NOT NULL,
	`side` enum('debit','credit') NOT NULL,
	`accountCode` varchar(10) NOT NULL,
	`accountName` varchar(100) NOT NULL,
	`subAccount` varchar(100),
	`amount` decimal(15,2) NOT NULL,
	`taxCategory` varchar(50),
	`taxRate` varchar(10),
	`taxAmount` decimal(15,2),
	`description` text,
	CONSTRAINT `journal_lines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `order_lines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderId` int NOT NULL,
	`itemName` varchar(255) NOT NULL,
	`quantity` decimal(10,2) NOT NULL,
	`unitPrice` decimal(15,2) NOT NULL,
	`taxRate` varchar(10) NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`taxAmount` decimal(15,2),
	CONSTRAINT `order_lines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orders` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orderNumber` varchar(50) NOT NULL,
	`orderType` enum('sales','purchase') NOT NULL,
	`partnerId` int,
	`orderDate` timestamp NOT NULL,
	`deliveryDate` timestamp,
	`status` enum('draft','confirmed','delivered','invoiced','completed','cancelled') NOT NULL DEFAULT 'draft',
	`subtotal` decimal(15,2),
	`taxAmount` decimal(15,2),
	`totalAmount` decimal(15,2),
	`notes` text,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `orders_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `partners` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`nameKana` varchar(255),
	`registrationNumber` varchar(20),
	`address` text,
	`phone` varchar(20),
	`email` varchar(320),
	`bankInfo` text,
	`category` enum('customer','supplier','both') NOT NULL DEFAULT 'both',
	`status` enum('active','inactive','merged') NOT NULL DEFAULT 'active',
	`mergedIntoId` int,
	`createdBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `partners_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `payment_schedules` (
	`id` int AUTO_INCREMENT NOT NULL,
	`invoiceId` int,
	`partnerId` int,
	`dueDate` timestamp NOT NULL,
	`amount` decimal(15,2) NOT NULL,
	`status` enum('scheduled','paid','overdue') NOT NULL DEFAULT 'scheduled',
	`paidAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `payment_schedules_id` PRIMARY KEY(`id`)
);
