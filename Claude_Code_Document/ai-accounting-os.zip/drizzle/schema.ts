import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, json, bigint, boolean } from "drizzle-orm/mysql-core";

// ===== Users =====
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ===== Trading Partners (取引先マスタ) =====
export const partners = mysqlTable("partners", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  nameKana: varchar("nameKana", { length: 255 }),
  registrationNumber: varchar("registrationNumber", { length: 20 }),
  address: text("address"),
  phone: varchar("phone", { length: 20 }),
  email: varchar("email", { length: 320 }),
  bankInfo: text("bankInfo"),
  category: mysqlEnum("category", ["customer", "supplier", "both"]).default("both").notNull(),
  status: mysqlEnum("status", ["active", "inactive", "merged"]).default("active").notNull(),
  mergedIntoId: int("mergedIntoId"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Partner = typeof partners.$inferSelect;

// ===== Documents (証憑) =====
export const documents = mysqlTable("documents", {
  id: int("id").autoincrement().primaryKey(),
  fileName: varchar("fileName", { length: 500 }).notNull(),
  fileUrl: text("fileUrl").notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  fileHash: varchar("fileHash", { length: 64 }),
  mimeType: varchar("mimeType", { length: 100 }),
  fileSize: int("fileSize"),
  documentType: mysqlEnum("documentType", ["invoice", "receipt", "delivery_note", "quotation", "contract", "bank_statement", "credit_card", "other"]).default("other").notNull(),
  status: mysqlEnum("status", ["uploaded", "processing", "extracted", "verified", "error"]).default("uploaded").notNull(),
  partnerId: int("partnerId"),
  documentDate: timestamp("documentDate"),
  amount: decimal("amount", { precision: 15, scale: 2 }),
  taxAmount: decimal("taxAmount", { precision: 15, scale: 2 }),
  taxRate: varchar("taxRate", { length: 10 }),
  registrationNumber: varchar("registrationNumber", { length: 20 }),
  extractedData: json("extractedData"),
  aiConfidence: decimal("aiConfidence", { precision: 3, scale: 2 }),
  uploadedBy: int("uploadedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Document = typeof documents.$inferSelect;

// ===== Journal Entries (仕訳) =====
export const journalEntries = mysqlTable("journal_entries", {
  id: int("id").autoincrement().primaryKey(),
  entryDate: timestamp("entryDate").notNull(),
  description: text("description"),
  status: mysqlEnum("status", ["draft", "confirmed", "cancelled"]).default("draft").notNull(),
  documentId: int("documentId"),
  partnerId: int("partnerId"),
  totalAmount: decimal("totalAmount", { precision: 15, scale: 2 }),
  aiGenerated: boolean("aiGenerated").default(false),
  aiConfidence: decimal("aiConfidence", { precision: 3, scale: 2 }),
  confirmedBy: int("confirmedBy"),
  confirmedAt: timestamp("confirmedAt"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type JournalEntry = typeof journalEntries.$inferSelect;

// ===== Journal Lines (仕訳明細) =====
export const journalLines = mysqlTable("journal_lines", {
  id: int("id").autoincrement().primaryKey(),
  journalEntryId: int("journalEntryId").notNull(),
  side: mysqlEnum("side", ["debit", "credit"]).notNull(),
  accountCode: varchar("accountCode", { length: 10 }).notNull(),
  accountName: varchar("accountName", { length: 100 }).notNull(),
  subAccount: varchar("subAccount", { length: 100 }),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  taxCategory: varchar("taxCategory", { length: 50 }),
  taxRate: varchar("taxRate", { length: 10 }),
  taxAmount: decimal("taxAmount", { precision: 15, scale: 2 }),
  description: text("description"),
});

export type JournalLine = typeof journalLines.$inferSelect;

// ===== AI Suggestions (AI候補) =====
export const aiSuggestions = mysqlTable("ai_suggestions", {
  id: int("id").autoincrement().primaryKey(),
  documentId: int("documentId").notNull(),
  rank: int("rank").notNull(),
  confidence: decimal("confidence", { precision: 3, scale: 2 }).notNull(),
  suggestion: json("suggestion").notNull(),
  reason: text("reason"),
  accepted: boolean("accepted").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AiSuggestion = typeof aiSuggestions.$inferSelect;

// ===== Orders (受注) =====
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderNumber: varchar("orderNumber", { length: 50 }).notNull(),
  orderType: mysqlEnum("orderType", ["sales", "purchase"]).notNull(),
  partnerId: int("partnerId"),
  orderDate: timestamp("orderDate").notNull(),
  deliveryDate: timestamp("deliveryDate"),
  status: mysqlEnum("status", ["draft", "confirmed", "delivered", "invoiced", "completed", "cancelled"]).default("draft").notNull(),
  subtotal: decimal("subtotal", { precision: 15, scale: 2 }),
  taxAmount: decimal("taxAmount", { precision: 15, scale: 2 }),
  totalAmount: decimal("totalAmount", { precision: 15, scale: 2 }),
  notes: text("notes"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;

// ===== Order Lines (受注明細) =====
export const orderLines = mysqlTable("order_lines", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  itemName: varchar("itemName", { length: 255 }).notNull(),
  quantity: decimal("quantity", { precision: 10, scale: 2 }).notNull(),
  unitPrice: decimal("unitPrice", { precision: 15, scale: 2 }).notNull(),
  taxRate: varchar("taxRate", { length: 10 }).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  taxAmount: decimal("taxAmount", { precision: 15, scale: 2 }),
});

export type OrderLine = typeof orderLines.$inferSelect;

// ===== Invoices (請求書) =====
export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  invoiceNumber: varchar("invoiceNumber", { length: 50 }).notNull(),
  invoiceType: mysqlEnum("invoiceType", ["issued", "received"]).notNull(),
  orderId: int("orderId"),
  partnerId: int("partnerId"),
  issueDate: timestamp("issueDate").notNull(),
  dueDate: timestamp("dueDate"),
  status: mysqlEnum("status", ["draft", "issued", "sent", "paid", "overdue", "cancelled"]).default("draft").notNull(),
  subtotal: decimal("subtotal", { precision: 15, scale: 2 }),
  taxAmount: decimal("taxAmount", { precision: 15, scale: 2 }),
  totalAmount: decimal("totalAmount", { precision: 15, scale: 2 }),
  registrationNumber: varchar("registrationNumber", { length: 20 }),
  invoiceChecks: json("invoiceChecks"),
  fileUrl: text("fileUrl"),
  fileKey: varchar("fileKey", { length: 500 }),
  journalEntryId: int("journalEntryId"),
  createdBy: int("createdBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Invoice = typeof invoices.$inferSelect;

// ===== Approvals (決裁) =====
export const approvals = mysqlTable("approvals", {
  id: int("id").autoincrement().primaryKey(),
  approvalType: mysqlEnum("approvalType", ["payment", "expense", "reimbursement", "partner_change"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  amount: decimal("amount", { precision: 15, scale: 2 }),
  partnerId: int("partnerId"),
  documentId: int("documentId"),
  status: mysqlEnum("status", ["pending", "approved", "rejected", "returned"]).default("pending").notNull(),
  riskScore: int("riskScore"),
  riskReasons: json("riskReasons"),
  aiReview: json("aiReview"),
  requestedBy: int("requestedBy"),
  approvedBy: int("approvedBy"),
  approvedAt: timestamp("approvedAt"),
  comment: text("comment"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Approval = typeof approvals.$inferSelect;

// ===== Audit Logs (監査ログ) =====
export const auditLogs = mysqlTable("audit_logs", {
  id: int("id").autoincrement().primaryKey(),
  action: varchar("action", { length: 50 }).notNull(),
  entityType: varchar("entityType", { length: 50 }).notNull(),
  entityId: int("entityId"),
  details: json("details"),
  aiInput: json("aiInput"),
  aiOutput: json("aiOutput"),
  aiConfidence: decimal("aiConfidence", { precision: 3, scale: 2 }),
  userId: int("userId"),
  userName: varchar("userName", { length: 255 }),
  ipAddress: varchar("ipAddress", { length: 45 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AuditLog = typeof auditLogs.$inferSelect;

// ===== Payment Schedule (支払予定) =====
export const paymentSchedules = mysqlTable("payment_schedules", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoiceId"),
  partnerId: int("partnerId"),
  dueDate: timestamp("dueDate").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  status: mysqlEnum("status", ["scheduled", "paid", "overdue"]).default("scheduled").notNull(),
  paidAt: timestamp("paidAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type PaymentSchedule = typeof paymentSchedules.$inferSelect;
