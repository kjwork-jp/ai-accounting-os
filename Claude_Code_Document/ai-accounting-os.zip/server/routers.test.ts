import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createContext(): { ctx: TrpcContext } {
  const ctx: TrpcContext = {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
  return { ctx };
}

describe("auth.me (no auth mode)", () => {
  it("returns null since auth is disabled", async () => {
    const { ctx } = createContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.me();
    expect(result).toBeNull();
  });
});

describe("auth.logout (no auth mode)", () => {
  it("returns success without cookie operations", async () => {
    const { ctx } = createContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.auth.logout();
    expect(result).toEqual({ success: true });
  });
});

describe("router structure", () => {
  it("has all required routers defined", () => {
    const { ctx } = createContext();
    const caller = appRouter.createCaller(ctx);

    expect(caller.auth).toBeDefined();
    expect(caller.dashboard).toBeDefined();
    expect(caller.partners).toBeDefined();
    expect(caller.documents).toBeDefined();
    expect(caller.journals).toBeDefined();
    expect(caller.orders).toBeDefined();
    expect(caller.invoices).toBeDefined();
    expect(caller.approvals).toBeDefined();
    expect(caller.auditLogs).toBeDefined();
    expect(caller.paymentSchedules).toBeDefined();
    expect(caller.analysis).toBeDefined();
  });

  it("has all required procedures in each router", () => {
    const { ctx } = createContext();
    const caller = appRouter.createCaller(ctx);

    // Auth
    expect(typeof caller.auth.me).toBe("function");
    expect(typeof caller.auth.logout).toBe("function");

    // Dashboard
    expect(typeof caller.dashboard.stats).toBe("function");
    expect(typeof caller.dashboard.monthlySales).toBe("function");
    expect(typeof caller.dashboard.expenseByCategory).toBe("function");
    expect(typeof caller.dashboard.upcomingPayments).toBe("function");

    // Partners
    expect(typeof caller.partners.list).toBe("function");
    expect(typeof caller.partners.create).toBe("function");
    expect(typeof caller.partners.update).toBe("function");

    // Documents
    expect(typeof caller.documents.list).toBe("function");
    expect(typeof caller.documents.upload).toBe("function");
    expect(typeof caller.documents.getById).toBe("function");
    expect(typeof caller.documents.analyze).toBe("function");
    expect(typeof caller.documents.getSuggestions).toBe("function");

    // Journals
    expect(typeof caller.journals.list).toBe("function");
    expect(typeof caller.journals.create).toBe("function");
    expect(typeof caller.journals.getLines).toBe("function");
    expect(typeof caller.journals.confirm).toBe("function");

    // Orders
    expect(typeof caller.orders.list).toBe("function");
    expect(typeof caller.orders.create).toBe("function");
    expect(typeof caller.orders.getLines).toBe("function");

    // Invoices
    expect(typeof caller.invoices.list).toBe("function");
    expect(typeof caller.invoices.create).toBe("function");

    // Approvals
    expect(typeof caller.approvals.list).toBe("function");
    expect(typeof caller.approvals.create).toBe("function");
    expect(typeof caller.approvals.approve).toBe("function");
    expect(typeof caller.approvals.reject).toBe("function");
    expect(typeof caller.approvals.return).toBe("function");

    // Audit Logs
    expect(typeof caller.auditLogs.list).toBe("function");

    // Payment Schedules
    expect(typeof caller.paymentSchedules.list).toBe("function");

    // Analysis
    expect(typeof caller.analysis.generateReport).toBe("function");
  });
});
