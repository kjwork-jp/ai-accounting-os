import { eq, desc, and, like, sql, gte, lte, or, asc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, partners, documents, journalEntries, journalLines, aiSuggestions, orders, orderLines, invoices, approvals, auditLogs, paymentSchedules } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ===== User Queries =====
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) { console.warn("[Database] Cannot upsert user: database not available"); return; }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) { values.lastSignedIn = user.lastSignedIn; updateSet.lastSignedIn = user.lastSignedIn; }
    if (user.role !== undefined) { values.role = user.role; updateSet.role = user.role; } else if (user.openId === ENV.ownerOpenId) { values.role = 'admin'; updateSet.role = 'admin'; }
    if (!values.lastSignedIn) values.lastSignedIn = new Date();
    if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) { console.error("[Database] Failed to upsert user:", error); throw error; }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ===== Partner Queries =====
export async function getPartners(search?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions = [eq(partners.status, "active")];
  if (search) conditions.push(or(like(partners.name, `%${search}%`), like(partners.nameKana, `%${search}%`))!);
  return db.select().from(partners).where(and(...conditions)).orderBy(desc(partners.updatedAt));
}

export async function createPartner(data: Omit<typeof partners.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(partners).values(data);
  return { id: result[0].insertId };
}

export async function updatePartner(id: number, data: Partial<typeof partners.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(partners).set(data).where(eq(partners.id, id));
}

// ===== Document Queries =====
export async function getDocuments(filters?: { status?: string; type?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (filters?.status) conditions.push(eq(documents.status, filters.status as any));
  if (filters?.type) conditions.push(eq(documents.documentType, filters.type as any));
  return db.select().from(documents).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(documents.createdAt));
}

export async function createDocument(data: Omit<typeof documents.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(documents).values(data);
  return { id: result[0].insertId };
}

export async function updateDocument(id: number, data: Partial<typeof documents.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(documents).set(data).where(eq(documents.id, id));
}

export async function getDocumentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(documents).where(eq(documents.id, id)).limit(1);
  return result[0];
}

// ===== Journal Queries =====
export async function getJournalEntries(filters?: { status?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (filters?.status) conditions.push(eq(journalEntries.status, filters.status as any));
  return db.select().from(journalEntries).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(journalEntries.entryDate));
}

export async function createJournalEntry(entry: Omit<typeof journalEntries.$inferInsert, "id" | "createdAt" | "updatedAt">, lines: Omit<typeof journalLines.$inferInsert, "id" | "journalEntryId">[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(journalEntries).values(entry);
  const entryId = result[0].insertId;
  if (lines.length > 0) {
    await db.insert(journalLines).values(lines.map(l => ({ ...l, journalEntryId: entryId })));
  }
  return { id: entryId };
}

export async function getJournalLines(entryId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(journalLines).where(eq(journalLines.journalEntryId, entryId));
}

export async function confirmJournalEntry(id: number, userId: number) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(journalEntries).set({ status: "confirmed", confirmedBy: userId, confirmedAt: new Date() }).where(eq(journalEntries.id, id));
}

// ===== AI Suggestion Queries =====
export async function createAiSuggestions(docId: number, suggestions: { rank: number; confidence: string; suggestion: any; reason: string }[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.insert(aiSuggestions).values(suggestions.map(s => ({ ...s, documentId: docId })));
}

export async function getAiSuggestions(docId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(aiSuggestions).where(eq(aiSuggestions.documentId, docId)).orderBy(asc(aiSuggestions.rank));
}

// ===== Order Queries =====
export async function getOrders(type?: "sales" | "purchase") {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (type) conditions.push(eq(orders.orderType, type));
  return db.select().from(orders).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(orders.orderDate));
}

export async function createOrder(order: Omit<typeof orders.$inferInsert, "id" | "createdAt" | "updatedAt">, lines: Omit<typeof orderLines.$inferInsert, "id" | "orderId">[]) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(orders).values(order);
  const orderId = result[0].insertId;
  if (lines.length > 0) {
    await db.insert(orderLines).values(lines.map(l => ({ ...l, orderId })));
  }
  return { id: orderId };
}

export async function getOrderLines(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderLines).where(eq(orderLines.orderId, orderId));
}

// ===== Invoice Queries =====
export async function getInvoices(type?: "issued" | "received") {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (type) conditions.push(eq(invoices.invoiceType, type));
  return db.select().from(invoices).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(invoices.issueDate));
}

export async function createInvoice(data: Omit<typeof invoices.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(invoices).values(data);
  return { id: result[0].insertId };
}

// ===== Approval Queries =====
export async function getApprovals(filters?: { status?: string }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (filters?.status) conditions.push(eq(approvals.status, filters.status as any));
  return db.select().from(approvals).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(approvals.createdAt));
}

export async function createApproval(data: Omit<typeof approvals.$inferInsert, "id" | "createdAt" | "updatedAt">) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  const result = await db.insert(approvals).values(data);
  return { id: result[0].insertId };
}

export async function updateApproval(id: number, data: Partial<typeof approvals.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("DB not available");
  await db.update(approvals).set(data).where(eq(approvals.id, id));
}

// ===== Audit Log Queries =====
export async function createAuditLog(data: Omit<typeof auditLogs.$inferInsert, "id" | "createdAt">) {
  const db = await getDb();
  if (!db) return;
  await db.insert(auditLogs).values(data);
}

export async function getAuditLogs(filters?: { action?: string; entityType?: string; userId?: number; from?: Date; to?: Date }) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (filters?.action) conditions.push(eq(auditLogs.action, filters.action));
  if (filters?.entityType) conditions.push(eq(auditLogs.entityType, filters.entityType));
  if (filters?.userId) conditions.push(eq(auditLogs.userId, filters.userId));
  if (filters?.from) conditions.push(gte(auditLogs.createdAt, filters.from));
  if (filters?.to) conditions.push(lte(auditLogs.createdAt, filters.to));
  return db.select().from(auditLogs).where(conditions.length ? and(...conditions) : undefined).orderBy(desc(auditLogs.createdAt)).limit(200);
}

// ===== Payment Schedule Queries =====
export async function getPaymentSchedules(status?: string) {
  const db = await getDb();
  if (!db) return [];
  const conditions: any[] = [];
  if (status) conditions.push(eq(paymentSchedules.status, status as any));
  return db.select().from(paymentSchedules).where(conditions.length ? and(...conditions) : undefined).orderBy(asc(paymentSchedules.dueDate));
}

// ===== Payment Alert Queries =====
export async function getUpcomingPayments() {
  const db = await getDb();
  if (!db) return [];
  // Get payments due within the next 14 days or overdue, joined with partner info
  const rows = await db.execute(sql`
    SELECT 
      ps.id,
      ps.invoiceId,
      ps.partnerId,
      ps.dueDate,
      ps.amount,
      ps.status,
      p.name as partnerName,
      DATEDIFF(ps.dueDate, NOW()) as daysUntilDue
    FROM payment_schedules ps
    LEFT JOIN partners p ON ps.partnerId = p.id
    WHERE ps.status != 'paid'
      AND ps.dueDate <= DATE_ADD(CURDATE(), INTERVAL 14 DAY)
    ORDER BY ps.dueDate ASC
    LIMIT 20
  `);
  return ((rows as any)[0] ?? []).map((r: any) => ({
    id: r.id,
    invoiceId: r.invoiceId,
    partnerId: r.partnerId,
    dueDate: r.dueDate,
    amount: Number(r.amount),
    status: r.status as string,
    partnerName: r.partnerName as string | null,
    daysUntilDue: Number(r.daysUntilDue),
  }));
}

// ===== Chart Data Queries =====
export async function getMonthlySalesData() {
  const db = await getDb();
  if (!db) return [];
  // Get monthly sales from invoices (issued) over the last 12 months
  const rows = await db.execute(sql`
    SELECT 
      DATE_FORMAT(issueDate, '%Y-%m') as month,
      COALESCE(SUM(CAST(totalAmount AS DECIMAL(15,0))), 0) as sales,
      COUNT(*) as count
    FROM invoices 
    WHERE invoiceType = 'issued'
      AND issueDate >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(issueDate, '%Y-%m')
    ORDER BY month ASC
  `);
  // Also get order-based sales data for a richer dataset
  const orderRows = await db.execute(sql`
    SELECT 
      DATE_FORMAT(orderDate, '%Y-%m') as month,
      COALESCE(SUM(CAST(totalAmount AS DECIMAL(15,0))), 0) as sales,
      COUNT(*) as count
    FROM orders 
    WHERE orderType = 'sales'
      AND orderDate >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(orderDate, '%Y-%m')
    ORDER BY month ASC
  `);
  // Merge both data sources, preferring order data for completeness
  const monthMap = new Map<string, { month: string; invoiceSales: number; orderSales: number; invoiceCount: number; orderCount: number }>();
  // Generate last 12 months
  for (let i = 11; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
    monthMap.set(key, { month: key, invoiceSales: 0, orderSales: 0, invoiceCount: 0, orderCount: 0 });
  }
  for (const row of (rows as any)[0] ?? []) {
    const entry = monthMap.get(row.month);
    if (entry) { entry.invoiceSales = Number(row.sales); entry.invoiceCount = Number(row.count); }
  }
  for (const row of (orderRows as any)[0] ?? []) {
    const entry = monthMap.get(row.month);
    if (entry) { entry.orderSales = Number(row.sales); entry.orderCount = Number(row.count); }
  }
  return Array.from(monthMap.values()).map(e => ({
    month: e.month,
    sales: Math.max(e.invoiceSales, e.orderSales),
    count: Math.max(e.invoiceCount, e.orderCount),
  }));
}

export async function getExpenseByCategory() {
  const db = await getDb();
  if (!db) return [];
  // Get expense breakdown by account from journal lines (debit side = expenses)
  const rows = await db.execute(sql`
    SELECT 
      jl.accountName as category,
      jl.accountCode as code,
      COALESCE(SUM(CAST(jl.amount AS DECIMAL(15,0))), 0) as amount,
      COUNT(*) as count
    FROM journal_lines jl
    JOIN journal_entries je ON je.id = jl.journalEntryId
    WHERE jl.side = 'debit'
      AND jl.accountCode LIKE '5%' OR jl.accountCode LIKE '6%' OR jl.accountCode LIKE '7%' OR jl.accountCode LIKE '8%'
    GROUP BY jl.accountName, jl.accountCode
    ORDER BY amount DESC
    LIMIT 10
  `);
  return ((rows as any)[0] ?? []).map((r: any) => ({
    category: r.category,
    code: r.code,
    amount: Number(r.amount),
    count: Number(r.count),
  }));
}

// ===== Dashboard Stats =====
export async function getDashboardStats() {
  const db = await getDb();
  if (!db) return { documents: 0, journals: 0, pendingApprovals: 0, partners: 0 };
  const [docCount] = await db.select({ count: sql<number>`count(*)` }).from(documents);
  const [journalCount] = await db.select({ count: sql<number>`count(*)` }).from(journalEntries);
  const [approvalCount] = await db.select({ count: sql<number>`count(*)` }).from(approvals).where(eq(approvals.status, "pending"));
  const [partnerCount] = await db.select({ count: sql<number>`count(*)` }).from(partners).where(eq(partners.status, "active"));
  return {
    documents: docCount?.count ?? 0,
    journals: journalCount?.count ?? 0,
    pendingApprovals: approvalCount?.count ?? 0,
    partners: partnerCount?.count ?? 0,
  };
}
