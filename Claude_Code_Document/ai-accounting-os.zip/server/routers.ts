import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { storagePut } from "./storage";
import { invokeLLM } from "./_core/llm";
import { nanoid } from "nanoid";

// Default user for demo (no auth)
const DEMO_USER = { id: 1, name: "デモユーザー" };

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(() => null),
    logout: publicProcedure.mutation(() => ({ success: true } as const)),
  }),

  // ===== Dashboard =====
  dashboard: router({
    stats: publicProcedure.query(async () => {
      return db.getDashboardStats();
    }),
    monthlySales: publicProcedure.query(async () => {
      return db.getMonthlySalesData();
    }),
    expenseByCategory: publicProcedure.query(async () => {
      return db.getExpenseByCategory();
    }),
    upcomingPayments: publicProcedure.query(async () => {
      return db.getUpcomingPayments();
    }),
  }),

  // ===== Partners (取引先) =====
  partners: router({
    list: publicProcedure.input(z.object({ search: z.string().optional() }).optional()).query(async ({ input }) => {
      return db.getPartners(input?.search);
    }),
    create: publicProcedure.input(z.object({
      name: z.string(),
      nameKana: z.string().optional(),
      registrationNumber: z.string().optional(),
      address: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
      bankInfo: z.string().optional(),
      category: z.enum(["customer", "supplier", "both"]).default("both"),
    })).mutation(async ({ input }) => {
      const result = await db.createPartner({ ...input, createdBy: DEMO_USER.id });
      await db.createAuditLog({ action: "create", entityType: "partner", entityId: result.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
      return result;
    }),
    update: publicProcedure.input(z.object({
      id: z.number(),
      name: z.string().optional(),
      nameKana: z.string().optional(),
      registrationNumber: z.string().optional(),
      address: z.string().optional(),
      phone: z.string().optional(),
      email: z.string().optional(),
      bankInfo: z.string().optional(),
      category: z.enum(["customer", "supplier", "both"]).optional(),
      status: z.enum(["active", "inactive", "merged"]).optional(),
    })).mutation(async ({ input }) => {
      const { id, ...data } = input;
      await db.updatePartner(id, data);
      await db.createAuditLog({ action: "update", entityType: "partner", entityId: id, userId: DEMO_USER.id, userName: DEMO_USER.name, details: data });
    }),
  }),

  // ===== Documents (証憑) =====
  documents: router({
    list: publicProcedure.input(z.object({ status: z.string().optional(), type: z.string().optional() }).optional()).query(async ({ input }) => {
      return db.getDocuments(input);
    }),
    upload: publicProcedure.input(z.object({
      fileName: z.string(),
      fileData: z.string(), // base64
      mimeType: z.string(),
      fileSize: z.number(),
    })).mutation(async ({ input }) => {
      const buffer = Buffer.from(input.fileData, "base64");
      const fileKey = `documents/${DEMO_USER.id}/${nanoid()}-${input.fileName}`;
      const { url } = await storagePut(fileKey, buffer, input.mimeType);
      const result = await db.createDocument({
        fileName: input.fileName,
        fileUrl: url,
        fileKey,
        mimeType: input.mimeType,
        fileSize: input.fileSize,
        uploadedBy: DEMO_USER.id,
        status: "uploaded",
        documentType: "other",
      });
      await db.createAuditLog({ action: "upload", entityType: "document", entityId: result.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
      return { id: result.id, url };
    }),
    getById: publicProcedure.input(z.object({ id: z.number() })).query(async ({ input }) => {
      return db.getDocumentById(input.id);
    }),
    analyze: publicProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      const doc = await db.getDocumentById(input.id);
      if (!doc) throw new Error("Document not found");
      await db.updateDocument(input.id, { status: "processing" });
      try {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: `あなたは日本の会計・経理の専門家AIです。証憑（請求書・領収書等）の画像やPDFから情報を抽出し、仕訳候補を生成してください。インボイス制度（適格請求書等保存方式）に対応してください。必ず以下のJSON形式で回答してください。` },
            { role: "user", content: `以下の証憑ファイルを分析してください。ファイル名: ${doc.fileName}, タイプ: ${doc.mimeType}\n\n以下の情報を抽出し、仕訳候補Top3を生成してください:\n1. 文書種別（invoice/receipt/delivery_note/quotation/contract/other）\n2. 取引先名\n3. 取引日\n4. 金額（税抜）\n5. 消費税額\n6. 税率\n7. 適格請求書登録番号\n8. 仕訳候補Top3（各候補に信頼度スコア0.00-1.00を付与）` },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "document_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  documentType: { type: "string", enum: ["invoice", "receipt", "delivery_note", "quotation", "contract", "other"] },
                  partnerName: { type: "string" },
                  documentDate: { type: "string" },
                  amount: { type: "number" },
                  taxAmount: { type: "number" },
                  taxRate: { type: "string" },
                  registrationNumber: { type: "string" },
                  suggestions: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        rank: { type: "integer" },
                        confidence: { type: "number" },
                        debitAccount: { type: "string" },
                        debitAccountCode: { type: "string" },
                        creditAccount: { type: "string" },
                        creditAccountCode: { type: "string" },
                        taxCategory: { type: "string" },
                        description: { type: "string" },
                        reason: { type: "string" },
                      },
                      required: ["rank", "confidence", "debitAccount", "debitAccountCode", "creditAccount", "creditAccountCode", "taxCategory", "description", "reason"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["documentType", "partnerName", "documentDate", "amount", "taxAmount", "taxRate", "registrationNumber", "suggestions"],
                additionalProperties: false,
              },
            },
          },
        });
        const content = response.choices[0]?.message?.content;
        const parsed = typeof content === "string" ? JSON.parse(content) : null;
        if (parsed) {
          await db.updateDocument(input.id, {
            status: "extracted",
            documentType: parsed.documentType,
            amount: String(parsed.amount),
            taxAmount: String(parsed.taxAmount),
            taxRate: parsed.taxRate,
            registrationNumber: parsed.registrationNumber,
            extractedData: parsed,
            aiConfidence: String(parsed.suggestions?.[0]?.confidence ?? 0.5),
          });
          if (parsed.suggestions?.length) {
            await db.createAiSuggestions(input.id, parsed.suggestions.map((s: any) => ({
              rank: s.rank,
              confidence: String(s.confidence),
              suggestion: s,
              reason: s.reason,
            })));
          }
          await db.createAuditLog({
            action: "ai_analyze",
            entityType: "document",
            entityId: input.id,
            userId: DEMO_USER.id,
            userName: DEMO_USER.name,
            aiOutput: parsed,
            aiConfidence: String(parsed.suggestions?.[0]?.confidence ?? 0.5),
          });
        }
        return parsed;
      } catch (e) {
        await db.updateDocument(input.id, { status: "error" });
        throw e;
      }
    }),
    getSuggestions: publicProcedure.input(z.object({ documentId: z.number() })).query(async ({ input }) => {
      return db.getAiSuggestions(input.documentId);
    }),
  }),

  // ===== Journal Entries (仕訳) =====
  journals: router({
    list: publicProcedure.input(z.object({ status: z.string().optional() }).optional()).query(async ({ input }) => {
      return db.getJournalEntries(input);
    }),
    create: publicProcedure.input(z.object({
      entryDate: z.string(),
      description: z.string().optional(),
      documentId: z.number().optional(),
      partnerId: z.number().optional(),
      totalAmount: z.string().optional(),
      aiGenerated: z.boolean().optional(),
      aiConfidence: z.string().optional(),
      lines: z.array(z.object({
        side: z.enum(["debit", "credit"]),
        accountCode: z.string(),
        accountName: z.string(),
        subAccount: z.string().optional(),
        amount: z.string(),
        taxCategory: z.string().optional(),
        taxRate: z.string().optional(),
        taxAmount: z.string().optional(),
        description: z.string().optional(),
      })),
    })).mutation(async ({ input }) => {
      const { lines, entryDate, ...rest } = input;
      const result = await db.createJournalEntry({ ...rest, entryDate: new Date(entryDate), createdBy: DEMO_USER.id }, lines);
      await db.createAuditLog({ action: "create", entityType: "journal", entityId: result.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
      return result;
    }),
    getLines: publicProcedure.input(z.object({ entryId: z.number() })).query(async ({ input }) => {
      return db.getJournalLines(input.entryId);
    }),
    confirm: publicProcedure.input(z.object({ id: z.number() })).mutation(async ({ input }) => {
      await db.confirmJournalEntry(input.id, DEMO_USER.id);
      await db.createAuditLog({ action: "confirm", entityType: "journal", entityId: input.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
    }),
  }),

  // ===== Orders (受注・発注) =====
  orders: router({
    list: publicProcedure.input(z.object({ type: z.enum(["sales", "purchase"]).optional() }).optional()).query(async ({ input }) => {
      return db.getOrders(input?.type);
    }),
    create: publicProcedure.input(z.object({
      orderNumber: z.string(),
      orderType: z.enum(["sales", "purchase"]),
      partnerId: z.number().optional(),
      orderDate: z.string(),
      deliveryDate: z.string().optional(),
      subtotal: z.string().optional(),
      taxAmount: z.string().optional(),
      totalAmount: z.string().optional(),
      notes: z.string().optional(),
      lines: z.array(z.object({
        itemName: z.string(),
        quantity: z.string(),
        unitPrice: z.string(),
        taxRate: z.string(),
        amount: z.string(),
        taxAmount: z.string().optional(),
      })),
    })).mutation(async ({ input }) => {
      const { lines, orderDate, deliveryDate, ...rest } = input;
      const result = await db.createOrder({
        ...rest,
        orderDate: new Date(orderDate),
        deliveryDate: deliveryDate ? new Date(deliveryDate) : undefined,
        createdBy: DEMO_USER.id,
      }, lines);
      await db.createAuditLog({ action: "create", entityType: "order", entityId: result.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
      return result;
    }),
    getLines: publicProcedure.input(z.object({ orderId: z.number() })).query(async ({ input }) => {
      return db.getOrderLines(input.orderId);
    }),
  }),

  // ===== Invoices (請求書) =====
  invoices: router({
    list: publicProcedure.input(z.object({ type: z.enum(["issued", "received"]).optional() }).optional()).query(async ({ input }) => {
      return db.getInvoices(input?.type);
    }),
    create: publicProcedure.input(z.object({
      invoiceNumber: z.string(),
      invoiceType: z.enum(["issued", "received"]),
      orderId: z.number().optional(),
      partnerId: z.number().optional(),
      issueDate: z.string(),
      dueDate: z.string().optional(),
      subtotal: z.string().optional(),
      taxAmount: z.string().optional(),
      totalAmount: z.string().optional(),
      registrationNumber: z.string().optional(),
    })).mutation(async ({ input }) => {
      const { issueDate, dueDate, ...rest } = input;
      const result = await db.createInvoice({
        ...rest,
        issueDate: new Date(issueDate),
        dueDate: dueDate ? new Date(dueDate) : undefined,
        createdBy: DEMO_USER.id,
      });
      await db.createAuditLog({ action: "create", entityType: "invoice", entityId: result.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
      return result;
    }),
  }),

  // ===== Approvals (決裁) =====
  approvals: router({
    list: publicProcedure.input(z.object({ status: z.string().optional() }).optional()).query(async ({ input }) => {
      return db.getApprovals(input);
    }),
    create: publicProcedure.input(z.object({
      approvalType: z.enum(["payment", "expense", "reimbursement", "partner_change"]),
      title: z.string(),
      description: z.string().optional(),
      amount: z.string().optional(),
      partnerId: z.number().optional(),
      documentId: z.number().optional(),
    })).mutation(async ({ input }) => {
      // AI risk scoring
      let riskScore = 0;
      let riskReasons: string[] = [];
      try {
        const response = await invokeLLM({
          messages: [
            { role: "system", content: "あなたは経理の承認審査AIです。申請内容を分析し、リスクスコア（0-100）と理由を返してください。" },
            { role: "user", content: `申請種別: ${input.approvalType}\nタイトル: ${input.title}\n説明: ${input.description ?? "なし"}\n金額: ${input.amount ?? "不明"}` },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "risk_assessment",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  riskScore: { type: "integer" },
                  reasons: { type: "array", items: { type: "string" } },
                },
                required: ["riskScore", "reasons"],
                additionalProperties: false,
              },
            },
          },
        });
        const content = response.choices[0]?.message?.content;
        const parsed = typeof content === "string" ? JSON.parse(content) : null;
        if (parsed) {
          riskScore = parsed.riskScore;
          riskReasons = parsed.reasons;
        }
      } catch (e) {
        console.error("Risk scoring failed:", e);
      }

      const result = await db.createApproval({
        ...input,
        requestedBy: DEMO_USER.id,
        riskScore,
        riskReasons,
      });
      await db.createAuditLog({ action: "create", entityType: "approval", entityId: result.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
      return { ...result, riskScore, riskReasons };
    }),
    approve: publicProcedure.input(z.object({ id: z.number(), comment: z.string().optional() })).mutation(async ({ input }) => {
      await db.updateApproval(input.id, { status: "approved", approvedBy: DEMO_USER.id, approvedAt: new Date(), comment: input.comment });
      await db.createAuditLog({ action: "approve", entityType: "approval", entityId: input.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
    }),
    reject: publicProcedure.input(z.object({ id: z.number(), comment: z.string().optional() })).mutation(async ({ input }) => {
      await db.updateApproval(input.id, { status: "rejected", approvedBy: DEMO_USER.id, approvedAt: new Date(), comment: input.comment });
      await db.createAuditLog({ action: "reject", entityType: "approval", entityId: input.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
    }),
    return: publicProcedure.input(z.object({ id: z.number(), comment: z.string().optional() })).mutation(async ({ input }) => {
      await db.updateApproval(input.id, { status: "returned", comment: input.comment });
      await db.createAuditLog({ action: "return", entityType: "approval", entityId: input.id, userId: DEMO_USER.id, userName: DEMO_USER.name });
    }),
  }),

  // ===== Audit Logs (監査ログ) =====
  auditLogs: router({
    list: publicProcedure.input(z.object({
      action: z.string().optional(),
      entityType: z.string().optional(),
      userId: z.number().optional(),
    }).optional()).query(async ({ input }) => {
      return db.getAuditLogs(input);
    }),
  }),

  // ===== Payment Schedules (支払予定) =====
  paymentSchedules: router({
    list: publicProcedure.input(z.object({ status: z.string().optional() }).optional()).query(async ({ input }) => {
      return db.getPaymentSchedules(input?.status);
    }),
  }),

  // ===== AI Analysis (経営分析) =====
  analysis: router({
    generateReport: publicProcedure.input(z.object({
      type: z.enum(["monthly_pl", "account_trend", "partner_analysis", "cash_flow"]),
      period: z.string().optional(),
    })).mutation(async ({ input }) => {
      const response = await invokeLLM({
        messages: [
          { role: "system", content: "あなたは経営分析AIです。会計データに基づいて分析レポートを生成してください。変動要因を自然言語で要約し、改善提案を含めてください。日本語で回答してください。" },
          { role: "user", content: `以下の分析レポートを生成してください:\nレポート種別: ${input.type}\n期間: ${input.period ?? "今月"}\n\nサンプルデータに基づいて、実際の経営分析レポートのようなデモデータを含めて生成してください。` },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "analysis_report",
            strict: true,
            schema: {
              type: "object",
              properties: {
                title: { type: "string" },
                summary: { type: "string" },
                keyMetrics: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      label: { type: "string" },
                      value: { type: "string" },
                      change: { type: "string" },
                      trend: { type: "string", enum: ["up", "down", "flat"] },
                    },
                    required: ["label", "value", "change", "trend"],
                    additionalProperties: false,
                  },
                },
                insights: { type: "array", items: { type: "string" } },
                recommendations: { type: "array", items: { type: "string" } },
                chartData: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      month: { type: "string" },
                      revenue: { type: "number" },
                      expense: { type: "number" },
                      profit: { type: "number" },
                    },
                    required: ["month", "revenue", "expense", "profit"],
                    additionalProperties: false,
                  },
                },
              },
              required: ["title", "summary", "keyMetrics", "insights", "recommendations", "chartData"],
              additionalProperties: false,
            },
          },
        },
      });
      const content = response.choices[0]?.message?.content;
      return typeof content === "string" ? JSON.parse(content) : null;
    }),
  }),
});

export type AppRouter = typeof appRouter;
