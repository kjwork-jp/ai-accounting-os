import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import Home from "./pages/Home";
import { lazy, Suspense } from "react";
import { Loader2 } from "lucide-react";

const Documents = lazy(() => import("./pages/Documents"));
const Journals = lazy(() => import("./pages/Journals"));
const SalesOrders = lazy(() => import("./pages/SalesOrders"));
const PurchaseOrders = lazy(() => import("./pages/PurchaseOrders"));
const Invoices = lazy(() => import("./pages/Invoices"));
const Approvals = lazy(() => import("./pages/Approvals"));
const Analytics = lazy(() => import("./pages/Analytics"));
const Partners = lazy(() => import("./pages/Partners"));
const AuditLogs = lazy(() => import("./pages/AuditLogs"));

function PageLoader() {
  return (
    <div className="flex items-center justify-center h-64">
      <Loader2 className="h-6 w-6 animate-spin text-primary" />
    </div>
  );
}

function Router() {
  return (
    <DashboardLayout>
      <Suspense fallback={<PageLoader />}>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/documents" component={Documents} />
          <Route path="/journals" component={Journals} />
          <Route path="/sales-orders" component={SalesOrders} />
          <Route path="/purchase-orders" component={PurchaseOrders} />
          <Route path="/invoices" component={Invoices} />
          <Route path="/approvals" component={Approvals} />
          <Route path="/analytics" component={Analytics} />
          <Route path="/partners" component={Partners} />
          <Route path="/audit-logs" component={AuditLogs} />
          <Route path="/404" component={NotFound} />
          <Route component={NotFound} />
        </Switch>
      </Suspense>
    </DashboardLayout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
