import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  FileText,
  BookOpen,
  CheckSquare,
  Users,
  TrendingUp,
  ArrowRight,
  Sparkles,
  Upload,
  AlertTriangle,
  Zap,
  Clock,
  CalendarClock,
  CircleAlert,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
  Cell,
} from "recharts";
import { useMemo } from "react";

function formatYen(value: number) {
  if (value >= 1_000_000) return `¥${(value / 1_000_000).toFixed(1)}M`;
  if (value >= 1_000) return `¥${(value / 1_000).toFixed(0)}K`;
  return `¥${value}`;
}

function formatMonth(month: string) {
  const parts = month.split("-");
  return `${parseInt(parts[1])}月`;
}

const CHART_COLORS = {
  primary: "oklch(0.55 0.18 250)",
  primaryLight: "oklch(0.55 0.18 250 / 0.08)",
  accent: "oklch(0.65 0.15 160)",
  bar1: "oklch(0.55 0.18 250)",
  bar2: "oklch(0.60 0.16 220)",
  bar3: "oklch(0.65 0.14 190)",
  bar4: "oklch(0.70 0.12 160)",
  bar5: "oklch(0.75 0.10 130)",
};

const BAR_COLORS = [
  "#4f46e5", "#6366f1", "#818cf8", "#a5b4fc", "#c7d2fe",
  "#7c3aed", "#8b5cf6", "#a78bfa", "#c4b5fd", "#ddd6fe",
];

function CustomTooltipSales({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-popover text-popover-foreground border rounded-lg shadow-lg px-4 py-3 text-sm">
      <p className="font-semibold mb-1">{label}</p>
      <p className="text-primary">
        売上: <span className="font-mono font-semibold">¥{Number(payload[0]?.value ?? 0).toLocaleString()}</span>
      </p>
    </div>
  );
}

function CustomTooltipExpense({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-popover text-popover-foreground border rounded-lg shadow-lg px-4 py-3 text-sm">
      <p className="font-semibold mb-1">{label}</p>
      <p className="text-primary">
        金額: <span className="font-mono font-semibold">¥{Number(payload[0]?.value ?? 0).toLocaleString()}</span>
      </p>
    </div>
  );
}

export default function Home() {
  const [, setLocation] = useLocation();
  const { data: stats, isLoading } = trpc.dashboard.stats.useQuery();
  const { data: monthlySales } = trpc.dashboard.monthlySales.useQuery();
  const { data: expenseData } = trpc.dashboard.expenseByCategory.useQuery();
  const { data: upcomingPayments } = trpc.dashboard.upcomingPayments.useQuery();

  const salesChartData = useMemo(() => {
    if (!monthlySales) return [];
    return monthlySales.map((d) => ({
      month: formatMonth(d.month),
      sales: d.sales,
    }));
  }, [monthlySales]);

  const expenseChartData = useMemo(() => {
    if (!expenseData) return [];
    return expenseData.map((d: { category: string; code: string; amount: number; count: number }, i: number) => ({
      category: d.category.length > 6 ? d.category.slice(0, 6) + "…" : d.category,
      fullCategory: d.category,
      amount: d.amount,
      fill: BAR_COLORS[i % BAR_COLORS.length],
    }));
  }, [expenseData]);

  const totalSales = useMemo(() => {
    return salesChartData.reduce((sum: number, d: { sales: number }) => sum + d.sales, 0);
  }, [salesChartData]);

  const totalExpense = useMemo(() => {
    return expenseChartData.reduce((sum: number, d: { amount: number }) => sum + d.amount, 0);
  }, [expenseChartData]);

  const statCards = [
    {
      title: "証憑",
      value: stats?.documents ?? 0,
      icon: FileText,
      description: "アップロード済み",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      path: "/documents",
    },
    {
      title: "仕訳",
      value: stats?.journals ?? 0,
      icon: BookOpen,
      description: "登録済み",
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
      path: "/journals",
    },
    {
      title: "承認待ち",
      value: stats?.pendingApprovals ?? 0,
      icon: CheckSquare,
      description: "決裁申請",
      color: "text-amber-600",
      bgColor: "bg-amber-50",
      path: "/approvals",
    },
    {
      title: "取引先",
      value: stats?.partners ?? 0,
      icon: Users,
      description: "登録済み",
      color: "text-violet-600",
      bgColor: "bg-violet-50",
      path: "/partners",
    },
  ];

  const quickActions = [
    { label: "証憑をアップロード", icon: Upload, path: "/documents", description: "PDF・画像をAIで自動解析" },
    { label: "請求書を作成", icon: FileText, path: "/invoices", description: "適格請求書を発行" },
    { label: "経営分析を表示", icon: TrendingUp, path: "/analytics", description: "AI分析レポートを生成" },
    { label: "決裁申請を確認", icon: CheckSquare, path: "/approvals", description: "承認待ちの申請を処理" },
  ];

  const recentActivities = [
    { action: "証憑アップロード", detail: "請求書_2026年1月分.pdf", time: "2分前", type: "upload" },
    { action: "AI仕訳生成", detail: "仕入高 / 買掛金 ¥150,000", time: "5分前", type: "ai" },
    { action: "決裁承認", detail: "経費精算 #APR-0042", time: "15分前", type: "approval" },
    { action: "請求書発行", detail: "INV-2026-0089 ¥330,000", time: "1時間前", type: "invoice" },
    { action: "取引先登録", detail: "株式会社テクノロジー", time: "2時間前", type: "partner" },
  ];

  return (
    <div className="space-y-5 sm:space-y-6 md:space-y-8">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">
          AI Business Accounting OS
        </h1>
        <p className="text-muted-foreground text-xs sm:text-sm">
          AI Business Accounting OS — 本日の業務概要です
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-4">
        {statCards.map((card) => (
          <Card
            key={card.title}
            className="card-hover cursor-pointer border-0 shadow-sm bg-card"
            onClick={() => setLocation(card.path)}
          >
            <CardContent className="p-3 sm:p-5">
              <div className="flex items-start justify-between">
                <div className="space-y-1 sm:space-y-2 min-w-0">
                  <p className="text-[10px] sm:text-xs font-medium text-muted-foreground uppercase tracking-wider">
                    {card.title}
                  </p>
                  <div className="flex items-baseline gap-1 sm:gap-2 flex-wrap">
                    <span className="text-xl sm:text-3xl font-bold tracking-tight">
                      {isLoading ? "—" : card.value.toLocaleString()}
                    </span>
                    <span className="text-[10px] sm:text-xs text-muted-foreground">{card.description}</span>
                  </div>
                </div>
                <div className={`h-8 w-8 sm:h-10 sm:w-10 rounded-xl ${card.bgColor} flex items-center justify-center shrink-0`}>
                  <card.icon className={`h-4 w-4 sm:h-5 sm:w-5 ${card.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
        {/* Monthly Sales Line Chart */}
        <Card className="border shadow-sm">
          <CardHeader className="pb-2 px-3 sm:px-6">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-sm sm:text-base font-semibold">月次売上推移</CardTitle>
                <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">過去12ヶ月の売上高推移</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] sm:text-xs text-muted-foreground">累計売上</p>
                <p className="text-sm sm:text-lg font-bold tracking-tight text-primary">
                  {formatYen(totalSales)}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0 pb-4 px-1 sm:px-6">
            {salesChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <AreaChart data={salesChartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="salesGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#4f46e5" stopOpacity={0.15} />
                      <stop offset="100%" stopColor="#4f46e5" stopOpacity={0.01} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0 0)" vertical={false} />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 11, fill: "oklch(0.55 0 0)" }}
                    axisLine={{ stroke: "oklch(0.9 0 0)" }}
                    tickLine={false}
                  />
                  <YAxis
                    tickFormatter={formatYen}
                    tick={{ fontSize: 11, fill: "oklch(0.55 0 0)" }}
                    axisLine={false}
                    tickLine={false}
                    width={65}
                  />
                  <Tooltip content={<CustomTooltipSales />} />
                  <Area
                    type="monotone"
                    dataKey="sales"
                    stroke="#4f46e5"
                    strokeWidth={2.5}
                    fill="url(#salesGradient)"
                    dot={{ r: 3, fill: "#4f46e5", strokeWidth: 2, stroke: "#fff" }}
                    activeDot={{ r: 5, fill: "#4f46e5", strokeWidth: 2, stroke: "#fff" }}
                  />
                </AreaChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[260px] flex items-center justify-center text-sm text-muted-foreground">
                データを読み込み中...
              </div>
            )}
          </CardContent>
        </Card>

        {/* Expense by Category Bar Chart */}
        <Card className="border shadow-sm">
          <CardHeader className="pb-2 px-3 sm:px-6">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-sm sm:text-base font-semibold">科目別費用内訳</CardTitle>
                <p className="text-[10px] sm:text-xs text-muted-foreground mt-1">勘定科目別の費用構成</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] sm:text-xs text-muted-foreground">費用合計</p>
                <p className="text-sm sm:text-lg font-bold tracking-tight text-primary">
                  {formatYen(totalExpense)}
                </p>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-0 pb-4 px-1 sm:px-6">
            {expenseChartData.length > 0 ? (
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={expenseChartData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }} barCategoryGap="20%">
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0 0)" vertical={false} />
                  <XAxis
                    dataKey="category"
                    tick={{ fontSize: 10, fill: "oklch(0.55 0 0)" }}
                    axisLine={{ stroke: "oklch(0.9 0 0)" }}
                    tickLine={false}
                    interval={0}
                    angle={-20}
                    textAnchor="end"
                    height={50}
                  />
                  <YAxis
                    tickFormatter={formatYen}
                    tick={{ fontSize: 11, fill: "oklch(0.55 0 0)" }}
                    axisLine={false}
                    tickLine={false}
                    width={65}
                  />
                  <Tooltip content={<CustomTooltipExpense />} />
                  <Bar
                    dataKey="amount"
                    radius={[6, 6, 0, 0]}
                    maxBarSize={48}
                  >
                    {expenseChartData.map((entry: { fill: string }, index: number) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-[260px] flex items-center justify-center text-sm text-muted-foreground">
                データを読み込み中...
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        {/* Quick Actions */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold tracking-tight">クイックアクション</h2>
            <Badge variant="secondary" className="text-xs font-normal gap-1">
              <Sparkles className="h-3 w-3" />
              AI対応
            </Badge>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-3">
            {quickActions.map((action) => (
              <Card
                key={action.label}
                className="card-hover cursor-pointer border shadow-none hover:border-primary/20 transition-all duration-300"
                onClick={() => setLocation(action.path)}
              >
                <CardContent className="p-3 sm:p-4 flex items-center gap-3 sm:gap-4">
                  <div className="h-9 w-9 sm:h-10 sm:w-10 rounded-xl bg-primary/5 flex items-center justify-center shrink-0">
                    <action.icon className="h-4 w-4 sm:h-5 sm:w-5 text-primary" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs sm:text-sm font-medium">{action.label}</p>
                    <p className="text-[10px] sm:text-xs text-muted-foreground truncate">{action.description}</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground/40 ml-auto shrink-0 hidden sm:block" />
                </CardContent>
              </Card>
            ))}
          </div>

          {/* AI Insights */}
          <Card className="border-primary/10 bg-gradient-to-br from-primary/[0.02] to-primary/[0.06]">
            <CardContent className="p-5">
              <div className="flex items-start gap-3">
                <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                  <Zap className="h-4.5 w-4.5 text-primary" />
                </div>
                <div className="space-y-1.5">
                  <p className="text-sm font-semibold">AI分析インサイト</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    今月の経費は前月比で12%増加しています。主な要因は外注費の増加（+¥280,000）です。
                    支払予定の確認と、来月の資金繰り計画の見直しを推奨します。
                  </p>
                  <Button
                    variant="link"
                    className="h-auto p-0 text-xs text-primary"
                    onClick={() => setLocation("/analytics")}
                  >
                    詳細分析を表示 →
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold tracking-tight">最近のアクティビティ</h2>
          <Card className="border shadow-none">
            <CardContent className="p-0">
              <div className="divide-y">
                {recentActivities.map((activity, i) => (
                  <div key={i} className="px-4 py-3 flex items-start gap-3 hover:bg-muted/30 transition-colors">
                    <div className={`h-7 w-7 rounded-lg flex items-center justify-center shrink-0 mt-0.5 ${
                      activity.type === "ai" ? "bg-violet-50" :
                      activity.type === "upload" ? "bg-blue-50" :
                      activity.type === "approval" ? "bg-emerald-50" :
                      activity.type === "invoice" ? "bg-amber-50" : "bg-slate-50"
                    }`}>
                      {activity.type === "ai" ? <Sparkles className="h-3.5 w-3.5 text-violet-600" /> :
                       activity.type === "upload" ? <Upload className="h-3.5 w-3.5 text-blue-600" /> :
                       activity.type === "approval" ? <CheckSquare className="h-3.5 w-3.5 text-emerald-600" /> :
                       activity.type === "invoice" ? <FileText className="h-3.5 w-3.5 text-amber-600" /> :
                       <Users className="h-3.5 w-3.5 text-slate-600" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-medium">{activity.action}</p>
                      <p className="text-xs text-muted-foreground truncate">{activity.detail}</p>
                    </div>
                    <span className="text-[10px] text-muted-foreground/60 shrink-0 mt-0.5">{activity.time}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Payment Due Alert Widget */}
          <Card className="border shadow-none">
            <CardHeader className="pb-2 pt-4 px-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CalendarClock className="h-4 w-4 text-amber-600" />
                  <CardTitle className="text-sm font-semibold">支払期日アラート</CardTitle>
                </div>
                {upcomingPayments && upcomingPayments.length > 0 && (
                  <Badge variant="destructive" className="text-[10px] px-1.5 py-0 h-5">
                    {upcomingPayments.length}件
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-0 pb-1">
              {upcomingPayments && upcomingPayments.length > 0 ? (
                <div className="divide-y">
                  {upcomingPayments.map((payment: { id: number; dueDate: string; amount: number; partnerName: string | null; daysUntilDue: number; status: string }) => {
                    const isOverdue = payment.daysUntilDue < 0;
                    const isUrgent = payment.daysUntilDue >= 0 && payment.daysUntilDue <= 3;
                    const isWarning = payment.daysUntilDue > 3 && payment.daysUntilDue <= 7;
                    return (
                      <div key={payment.id} className="px-4 py-2.5 flex items-center gap-3 hover:bg-muted/30 transition-colors">
                        <div className={`h-7 w-7 rounded-lg flex items-center justify-center shrink-0 ${
                          isOverdue ? "bg-red-100" : isUrgent ? "bg-amber-100" : isWarning ? "bg-yellow-50" : "bg-blue-50"
                        }`}>
                          {isOverdue ? (
                            <CircleAlert className="h-3.5 w-3.5 text-red-600" />
                          ) : isUrgent ? (
                            <AlertTriangle className="h-3.5 w-3.5 text-amber-600" />
                          ) : (
                            <Clock className="h-3.5 w-3.5 text-blue-600" />
                          )}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5">
                            <p className="text-xs font-medium truncate">
                              {payment.partnerName ?? "不明"}
                            </p>
                            <Badge
                              variant="outline"
                              className={`text-[9px] px-1 py-0 h-4 shrink-0 border ${
                                isOverdue
                                  ? "border-red-300 text-red-700 bg-red-50"
                                  : isUrgent
                                  ? "border-amber-300 text-amber-700 bg-amber-50"
                                  : isWarning
                                  ? "border-yellow-300 text-yellow-700 bg-yellow-50"
                                  : "border-blue-200 text-blue-600 bg-blue-50"
                              }`}
                            >
                              {isOverdue
                                ? `${Math.abs(payment.daysUntilDue)}日超過`
                                : payment.daysUntilDue === 0
                                ? "本日"
                                : `あと${payment.daysUntilDue}日`}
                            </Badge>
                          </div>
                          <p className="text-[10px] text-muted-foreground">
                            {new Date(payment.dueDate).toLocaleDateString("ja-JP")} ・ ¥{payment.amount.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="px-4 py-6 text-center">
                  <p className="text-xs text-muted-foreground">直近の支払予定はありません</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
