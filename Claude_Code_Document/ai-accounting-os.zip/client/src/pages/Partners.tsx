import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users, Plus, Loader2, Search, Building2, Pencil, Sparkles, GitMerge } from "lucide-react";
import { useState, useMemo } from "react";
import { toast } from "sonner";

const categoryLabels: Record<string, { label: string; className: string }> = {
  customer: { label: "得意先", className: "bg-blue-50 text-blue-700 border-blue-200" },
  supplier: { label: "仕入先", className: "bg-violet-50 text-violet-700 border-violet-200" },
  both: { label: "双方", className: "bg-slate-50 text-slate-700 border-slate-200" },
};

export default function Partners() {
  const [createOpen, setCreateOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [editPartner, setEditPartner] = useState<any>(null);
  const [search, setSearch] = useState("");
  const { data: partners, isLoading, refetch } = trpc.partners.list.useQuery({ search: search || undefined });
  const createMutation = trpc.partners.create.useMutation();
  const updateMutation = trpc.partners.update.useMutation();

  const [form, setForm] = useState({
    name: "", nameKana: "", registrationNumber: "", address: "",
    phone: "", email: "", bankInfo: "", category: "both" as "customer" | "supplier" | "both",
  });

  const handleCreate = async () => {
    try {
      await createMutation.mutateAsync({
        name: form.name, nameKana: form.nameKana || undefined,
        registrationNumber: form.registrationNumber || undefined,
        address: form.address || undefined, phone: form.phone || undefined,
        email: form.email || undefined, bankInfo: form.bankInfo || undefined,
        category: form.category,
      });
      toast.success("取引先を登録しました");
      setCreateOpen(false);
      setForm({ name: "", nameKana: "", registrationNumber: "", address: "", phone: "", email: "", bankInfo: "", category: "both" });
      refetch();
    } catch { toast.error("登録に失敗しました"); }
  };

  const handleEdit = async () => {
    if (!editPartner) return;
    try {
      await updateMutation.mutateAsync({
        id: editPartner.id,
        name: editPartner.name,
        nameKana: editPartner.nameKana || undefined,
        registrationNumber: editPartner.registrationNumber || undefined,
        address: editPartner.address || undefined,
        phone: editPartner.phone || undefined,
        email: editPartner.email || undefined,
        category: editPartner.category,
      });
      toast.success("取引先を更新しました");
      setEditOpen(false);
      refetch();
    } catch { toast.error("更新に失敗しました"); }
  };

  // Detect potential duplicate names (simple name similarity)
  const duplicateCandidates = useMemo(() => {
    if (!partners || partners.length < 2) return [];
    const candidates: { a: any; b: any }[] = [];
    for (let i = 0; i < partners.length; i++) {
      for (let j = i + 1; j < partners.length; j++) {
        const nameA = partners[i].name.replace(/[\s　株式会社(株)（株）有限会社]/g, "");
        const nameB = partners[j].name.replace(/[\s　株式会社(株)（株）有限会社]/g, "");
        if (nameA === nameB || nameA.includes(nameB) || nameB.includes(nameA)) {
          candidates.push({ a: partners[i], b: partners[j] });
        }
      }
    }
    return candidates;
  }, [partners]);

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">取引先マスタ</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">取引先の登録・管理と表記揺れの自動名寄せを行います</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-sm w-full sm:w-auto"><Plus className="h-4 w-4" />取引先登録</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] sm:max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader><DialogTitle>新規取引先登録</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><Label className="text-xs">取引先名 *</Label><Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="株式会社○○" /></div>
                <div><Label className="text-xs">フリガナ</Label><Input value={form.nameKana} onChange={e => setForm(p => ({ ...p, nameKana: e.target.value }))} placeholder="カブシキガイシャ" /></div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">区分</Label>
                  <Select value={form.category} onValueChange={(v: any) => setForm(p => ({ ...p, category: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="customer">得意先</SelectItem>
                      <SelectItem value="supplier">仕入先</SelectItem>
                      <SelectItem value="both">双方</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">登録番号</Label><Input value={form.registrationNumber} onChange={e => setForm(p => ({ ...p, registrationNumber: e.target.value }))} placeholder="T1234567890123" /></div>
              </div>
              <div><Label className="text-xs">住所</Label><Input value={form.address} onChange={e => setForm(p => ({ ...p, address: e.target.value }))} /></div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><Label className="text-xs">電話番号</Label><Input value={form.phone} onChange={e => setForm(p => ({ ...p, phone: e.target.value }))} /></div>
                <div><Label className="text-xs">メール</Label><Input value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} /></div>
              </div>
              <div><Label className="text-xs">振込先情報</Label><Input value={form.bankInfo} onChange={e => setForm(p => ({ ...p, bankInfo: e.target.value }))} placeholder="○○銀行 ○○支店 普通 1234567" /></div>
              <Button onClick={handleCreate} disabled={createMutation.isPending} className="w-full">
                {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}登録
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Name Merge Suggestions */}
      {duplicateCandidates.length > 0 && (
        <Card className="border-amber-200/50 bg-amber-50/30">
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              <div className="h-8 w-8 rounded-lg bg-amber-100 flex items-center justify-center shrink-0">
                <GitMerge className="h-4 w-4 text-amber-600" />
              </div>
              <div>
                <p className="text-sm font-semibold text-amber-800 flex items-center gap-2">
                  名寄せ候補が見つかりました
                  <Badge variant="outline" className="text-[10px] bg-amber-50 text-amber-700 border-amber-200 gap-1">
                    <Sparkles className="h-3 w-3" />AI検出
                  </Badge>
                </p>
                <div className="mt-2 space-y-1">
                  {duplicateCandidates.slice(0, 3).map((c, i) => (
                    <p key={i} className="text-xs text-amber-700">
                      「{c.a.name}」と「{c.b.name}」が類似しています
                    </p>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Search */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 sm:max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground/50" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="取引先名で検索..."
            className="pl-9"
          />
        </div>
      </div>

      {/* Table - Desktop */}
      <Card className="border shadow-none hidden md:block">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-xs font-medium">取引先名</TableHead>
                <TableHead className="text-xs font-medium">区分</TableHead>
                <TableHead className="text-xs font-medium">登録番号</TableHead>
                <TableHead className="text-xs font-medium">電話</TableHead>
                <TableHead className="text-xs font-medium">メール</TableHead>
                <TableHead className="text-xs font-medium text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-12"><Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
              ) : !partners?.length ? (
                <TableRow><TableCell colSpan={6} className="text-center py-12">
                  <Users className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">取引先がまだ登録されていません</p>
                </TableCell></TableRow>
              ) : partners.map((p: any) => {
                const cat = categoryLabels[p.category] ?? categoryLabels.both;
                return (
                  <TableRow key={p.id} className="group">
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <div className="h-8 w-8 rounded-lg bg-muted/50 flex items-center justify-center shrink-0">
                          <Building2 className="h-4 w-4 text-muted-foreground/60" />
                        </div>
                        <div>
                          <p className="text-sm font-medium">{p.name}</p>
                          {p.nameKana && <p className="text-[10px] text-muted-foreground">{p.nameKana}</p>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell><Badge variant="outline" className={`text-[10px] ${cat.className}`}>{cat.label}</Badge></TableCell>
                    <TableCell className="text-xs text-muted-foreground">{p.registrationNumber || "—"}</TableCell>
                    <TableCell className="text-xs">{p.phone || "—"}</TableCell>
                    <TableCell className="text-xs">{p.email || "—"}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost" size="sm"
                        className="h-7 text-xs gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => { setEditPartner({ ...p }); setEditOpen(true); }}
                      >
                        <Pencil className="h-3 w-3" />編集
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Cards - Mobile */}
      <div className="md:hidden space-y-2">
        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : !partners?.length ? (
          <Card className="border shadow-none"><CardContent className="py-12 text-center">
            <Users className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">取引先がまだ登録されていません</p>
          </CardContent></Card>
        ) : partners.map((p: any) => {
          const cat = categoryLabels[p.category] ?? categoryLabels.both;
          return (
            <Card key={p.id} className="border shadow-none">
              <CardContent className="p-3">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-2 min-w-0">
                    <div className="h-8 w-8 rounded-lg bg-muted/50 flex items-center justify-center shrink-0">
                      <Building2 className="h-4 w-4 text-muted-foreground/60" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-sm font-medium truncate">{p.name}</p>
                      {p.nameKana && <p className="text-[10px] text-muted-foreground">{p.nameKana}</p>}
                    </div>
                  </div>
                  <Badge variant="outline" className={`text-[10px] shrink-0 ${cat.className}`}>{cat.label}</Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{p.registrationNumber || "—"}</span>
                  <Button variant="ghost" size="sm" className="h-6 text-[10px] gap-0.5" onClick={() => { setEditPartner({ ...p }); setEditOpen(true); }}>
                    <Pencil className="h-3 w-3" />編集
                  </Button>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Edit Dialog */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>取引先編集</DialogTitle></DialogHeader>
          {editPartner && (
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><Label className="text-xs">取引先名</Label><Input value={editPartner.name} onChange={e => setEditPartner((p: any) => ({ ...p, name: e.target.value }))} /></div>
                <div><Label className="text-xs">フリガナ</Label><Input value={editPartner.nameKana ?? ""} onChange={e => setEditPartner((p: any) => ({ ...p, nameKana: e.target.value }))} /></div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><Label className="text-xs">登録番号</Label><Input value={editPartner.registrationNumber ?? ""} onChange={e => setEditPartner((p: any) => ({ ...p, registrationNumber: e.target.value }))} /></div>
                <div><Label className="text-xs">電話</Label><Input value={editPartner.phone ?? ""} onChange={e => setEditPartner((p: any) => ({ ...p, phone: e.target.value }))} /></div>
              </div>
              <div><Label className="text-xs">メール</Label><Input value={editPartner.email ?? ""} onChange={e => setEditPartner((p: any) => ({ ...p, email: e.target.value }))} /></div>
              <Button onClick={handleEdit} disabled={updateMutation.isPending} className="w-full">
                {updateMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}更新
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
