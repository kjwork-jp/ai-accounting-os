import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { CheckSquare, Plus, Loader2, CheckCircle2, XCircle, RotateCcw, ShieldAlert, Sparkles, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusConfig: Record<string, { label: string; className: string }> = {
  pending: { label: "承認待ち", className: "bg-amber-50 text-amber-700 border-amber-200" },
  approved: { label: "承認済", className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  rejected: { label: "却下", className: "bg-red-50 text-red-700 border-red-200" },
  returned: { label: "差戻し", className: "bg-orange-50 text-orange-700 border-orange-200" },
};

const typeLabels: Record<string, string> = {
  payment: "支払申請", expense: "経費申請", reimbursement: "立替精算", partner_change: "取引先変更",
};

export default function Approvals() {
  const [tab, setTab] = useState("pending");
  const [createOpen, setCreateOpen] = useState(false);
  const [actionComment, setActionComment] = useState("");
  const [actionId, setActionId] = useState<number | null>(null);
  const [actionType, setActionType] = useState<"approve" | "reject" | "return" | null>(null);

  const { data: approvals, isLoading, refetch } = trpc.approvals.list.useQuery(
    tab !== "all" ? { status: tab } : undefined
  );
  const createMutation = trpc.approvals.create.useMutation();
  const approveMutation = trpc.approvals.approve.useMutation();
  const rejectMutation = trpc.approvals.reject.useMutation();
  const returnMutation = trpc.approvals.return.useMutation();

  const [form, setForm] = useState({
    approvalType: "payment" as "payment" | "expense" | "reimbursement" | "partner_change",
    title: "", description: "", amount: "",
  });

  const handleCreate = async () => {
    try {
      const result = await createMutation.mutateAsync({
        approvalType: form.approvalType,
        title: form.title,
        description: form.description || undefined,
        amount: form.amount || undefined,
      });
      toast.success(`申請を作成しました（リスクスコア: ${result.riskScore}）`);
      setCreateOpen(false);
      setForm({ approvalType: "payment", title: "", description: "", amount: "" });
      refetch();
    } catch { toast.error("作成に失敗しました"); }
  };

  const handleAction = async () => {
    if (!actionId || !actionType) return;
    try {
      if (actionType === "approve") await approveMutation.mutateAsync({ id: actionId, comment: actionComment || undefined });
      else if (actionType === "reject") await rejectMutation.mutateAsync({ id: actionId, comment: actionComment || undefined });
      else await returnMutation.mutateAsync({ id: actionId, comment: actionComment || undefined });
      toast.success(actionType === "approve" ? "承認しました" : actionType === "reject" ? "却下しました" : "差し戻しました");
      setActionId(null); setActionType(null); setActionComment("");
      refetch();
    } catch { toast.error("処理に失敗しました"); }
  };

  const getRiskColor = (score: number) => {
    if (score >= 70) return "text-red-600";
    if (score >= 40) return "text-amber-600";
    return "text-emerald-600";
  };

  const getRiskBg = (score: number) => {
    if (score >= 70) return "bg-red-500";
    if (score >= 40) return "bg-amber-500";
    return "bg-emerald-500";
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">決裁ワークフロー</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">支払・経費・立替申請の承認処理とAIリスク審査を行います</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-sm w-full sm:w-auto"><Plus className="h-4 w-4" />新規申請</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] sm:max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader><DialogTitle>新規決裁申請</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div>
                <Label className="text-xs">申請種別</Label>
                <Select value={form.approvalType} onValueChange={(v: any) => setForm(p => ({ ...p, approvalType: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="payment">支払申請</SelectItem>
                    <SelectItem value="expense">経費申請</SelectItem>
                    <SelectItem value="reimbursement">立替精算</SelectItem>
                    <SelectItem value="partner_change">取引先変更</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div><Label className="text-xs">タイトル</Label><Input value={form.title} onChange={e => setForm(p => ({ ...p, title: e.target.value }))} placeholder="申請タイトル" /></div>
              <div><Label className="text-xs">金額</Label><Input type="number" value={form.amount} onChange={e => setForm(p => ({ ...p, amount: e.target.value }))} placeholder="0" /></div>
              <div><Label className="text-xs">説明</Label><Textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="申請内容の詳細" rows={3} /></div>
              <div className="bg-primary/5 rounded-lg p-3 flex items-start gap-2">
                <Sparkles className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground">AIが申請内容を自動審査し、リスクスコアを算出します</p>
              </div>
              <Button onClick={handleCreate} disabled={createMutation.isPending} className="w-full">
                {createMutation.isPending ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />AI審査中...</> : "申請する"}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="pending" className="text-xs">承認待ち</TabsTrigger>
          <TabsTrigger value="approved" className="text-xs">承認済</TabsTrigger>
          <TabsTrigger value="rejected" className="text-xs">却下</TabsTrigger>
          <TabsTrigger value="all" className="text-xs">すべて</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4">
          {/* Table - Desktop */}
          <Card className="border shadow-none hidden md:block">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-xs font-medium">タイトル</TableHead>
                    <TableHead className="text-xs font-medium">種別</TableHead>
                    <TableHead className="text-xs font-medium">金額</TableHead>
                    <TableHead className="text-xs font-medium">ステータス</TableHead>
                    <TableHead className="text-xs font-medium">リスクスコア</TableHead>
                    <TableHead className="text-xs font-medium">日時</TableHead>
                    <TableHead className="text-xs font-medium text-right">操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-12"><Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
                  ) : !approvals?.length ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-12">
                      <CheckSquare className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">申請がありません</p>
                    </TableCell></TableRow>
                  ) : approvals.map((a: any) => {
                    const st = statusConfig[a.status] ?? statusConfig.pending;
                    const risk = a.riskScore ?? 0;
                    return (
                      <TableRow key={a.id} className="group">
                        <TableCell>
                          <div>
                            <p className="text-sm font-medium">{a.title}</p>
                            {a.description && <p className="text-xs text-muted-foreground truncate max-w-[200px]">{a.description}</p>}
                          </div>
                        </TableCell>
                        <TableCell><span className="text-xs">{typeLabels[a.approvalType]}</span></TableCell>
                        <TableCell className="text-sm font-medium">{a.amount ? `¥${Number(a.amount).toLocaleString()}` : "—"}</TableCell>
                        <TableCell><Badge variant="outline" className={`text-[10px] ${st.className}`}>{st.label}</Badge></TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Progress value={risk} className={`h-1.5 w-12 [&>div]:${getRiskBg(risk)}`} />
                            <span className={`text-xs font-medium ${getRiskColor(risk)}`}>{risk}</span>
                            {risk >= 70 && <AlertTriangle className="h-3 w-3 text-red-500" />}
                          </div>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">{new Date(a.createdAt).toLocaleDateString("ja-JP")}</TableCell>
                        <TableCell className="text-right">
                          {a.status === "pending" && (
                            <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-emerald-600" onClick={() => { setActionId(a.id); setActionType("approve"); }}>
                                <CheckCircle2 className="h-3 w-3" />承認
                              </Button>
                              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-red-600" onClick={() => { setActionId(a.id); setActionType("reject"); }}>
                                <XCircle className="h-3 w-3" />却下
                              </Button>
                              <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 text-orange-600" onClick={() => { setActionId(a.id); setActionType("return"); }}>
                                <RotateCcw className="h-3 w-3" />差戻
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Cards - Mobile */}
          <div className="md:hidden space-y-2">
            {isLoading ? (
              <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : !approvals?.length ? (
              <Card className="border shadow-none"><CardContent className="py-12 text-center">
                <CheckSquare className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">申請がありません</p>
              </CardContent></Card>
            ) : approvals.map((a: any) => {
              const st = statusConfig[a.status] ?? statusConfig.pending;
              const risk = a.riskScore ?? 0;
              return (
                <Card key={a.id} className="border shadow-none">
                  <CardContent className="p-3">
                    <div className="flex items-start justify-between gap-2 mb-1.5">
                      <div className="min-w-0">
                        <p className="text-sm font-medium truncate">{a.title}</p>
                        <p className="text-[10px] text-muted-foreground">{typeLabels[a.approvalType]}</p>
                      </div>
                      <Badge variant="outline" className={`text-[10px] shrink-0 ${st.className}`}>{st.label}</Badge>
                    </div>
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="text-muted-foreground">{new Date(a.createdAt).toLocaleDateString("ja-JP")}</span>
                      <span className="font-medium">{a.amount ? `¥${Number(a.amount).toLocaleString()}` : "—"}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Progress value={risk} className={`h-1.5 w-16 [&>div]:${getRiskBg(risk)}`} />
                        <span className={`text-xs font-medium ${getRiskColor(risk)}`}>リスク: {risk}</span>
                        {risk >= 70 && <AlertTriangle className="h-3 w-3 text-red-500" />}
                      </div>
                      {a.status === "pending" && (
                        <div className="flex items-center gap-1">
                          <Button variant="outline" size="sm" className="h-6 text-[10px] gap-0.5 text-emerald-600" onClick={() => { setActionId(a.id); setActionType("approve"); }}>
                            <CheckCircle2 className="h-3 w-3" />
                          </Button>
                          <Button variant="outline" size="sm" className="h-6 text-[10px] gap-0.5 text-red-600" onClick={() => { setActionId(a.id); setActionType("reject"); }}>
                            <XCircle className="h-3 w-3" />
                          </Button>
                          <Button variant="outline" size="sm" className="h-6 text-[10px] gap-0.5 text-orange-600" onClick={() => { setActionId(a.id); setActionType("return"); }}>
                            <RotateCcw className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>

      {/* Action Dialog */}
      <Dialog open={!!actionId} onOpenChange={() => { setActionId(null); setActionType(null); setActionComment(""); }}>
        <DialogContent className="max-w-[95vw] sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{actionType === "approve" ? "承認" : actionType === "reject" ? "却下" : "差戻し"}確認</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div><Label className="text-xs">コメント（任意）</Label><Textarea value={actionComment} onChange={e => setActionComment(e.target.value)} placeholder="コメントを入力" rows={3} /></div>
            <Button onClick={handleAction} className="w-full" variant={actionType === "reject" ? "destructive" : "default"}>
              {actionType === "approve" ? "承認する" : actionType === "reject" ? "却下する" : "差し戻す"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
