import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Truck, Plus, Loader2, Calendar, AlertTriangle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusLabels: Record<string, { label: string; className: string }> = {
  draft: { label: "下書き", className: "bg-slate-50 text-slate-700 border-slate-200" },
  confirmed: { label: "確定", className: "bg-blue-50 text-blue-700 border-blue-200" },
  delivered: { label: "納品済", className: "bg-cyan-50 text-cyan-700 border-cyan-200" },
  invoiced: { label: "請求受領", className: "bg-violet-50 text-violet-700 border-violet-200" },
  completed: { label: "完了", className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  cancelled: { label: "キャンセル", className: "bg-red-50 text-red-700 border-red-200" },
};

export default function PurchaseOrders() {
  const [createOpen, setCreateOpen] = useState(false);
  const { data: orders, isLoading, refetch } = trpc.orders.list.useQuery({ type: "purchase" });
  const createMutation = trpc.orders.create.useMutation();
  const { data: schedules } = trpc.paymentSchedules.list.useQuery();

  const [form, setForm] = useState({
    orderNumber: "", orderDate: new Date().toISOString().split("T")[0],
    itemName: "", quantity: "1", unitPrice: "", taxRate: "10",
  });

  const handleCreate = async () => {
    const amount = (Number(form.quantity) * Number(form.unitPrice)).toString();
    const taxAmount = (Number(amount) * Number(form.taxRate) / 100).toString();
    try {
      await createMutation.mutateAsync({
        orderNumber: form.orderNumber || `PO-${Date.now()}`,
        orderType: "purchase",
        orderDate: form.orderDate,
        subtotal: amount,
        taxAmount,
        totalAmount: (Number(amount) + Number(taxAmount)).toString(),
        lines: [{
          itemName: form.itemName, quantity: form.quantity, unitPrice: form.unitPrice,
          taxRate: form.taxRate, amount, taxAmount,
        }],
      });
      toast.success("発注を作成しました");
      setCreateOpen(false);
      refetch();
    } catch { toast.error("作成に失敗しました"); }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">発注管理</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">発注・仕入の管理と支払予定表を確認します</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-sm w-full sm:w-auto"><Plus className="h-4 w-4" />発注登録</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] sm:max-w-lg">
            <DialogHeader><DialogTitle>新規発注登録</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><Label className="text-xs">発注番号</Label><Input value={form.orderNumber} onChange={e => setForm(p => ({ ...p, orderNumber: e.target.value }))} placeholder="自動採番" /></div>
                <div><Label className="text-xs">発注日</Label><Input type="date" value={form.orderDate} onChange={e => setForm(p => ({ ...p, orderDate: e.target.value }))} /></div>
              </div>
              <div><Label className="text-xs">品目・サービス名</Label><Input value={form.itemName} onChange={e => setForm(p => ({ ...p, itemName: e.target.value }))} placeholder="品目名" /></div>
              <div className="grid grid-cols-3 gap-3">
                <div><Label className="text-xs">数量</Label><Input type="number" value={form.quantity} onChange={e => setForm(p => ({ ...p, quantity: e.target.value }))} /></div>
                <div><Label className="text-xs">単価</Label><Input type="number" value={form.unitPrice} onChange={e => setForm(p => ({ ...p, unitPrice: e.target.value }))} placeholder="0" /></div>
                <div><Label className="text-xs">税率(%)</Label><Input type="number" value={form.taxRate} onChange={e => setForm(p => ({ ...p, taxRate: e.target.value }))} /></div>
              </div>
              <Button onClick={handleCreate} disabled={createMutation.isPending} className="w-full">
                {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}登録
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
        <div className="lg:col-span-2">
          {/* Table - Desktop */}
          <Card className="border shadow-none hidden md:block">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-xs font-medium">発注番号</TableHead>
                    <TableHead className="text-xs font-medium">発注日</TableHead>
                    <TableHead className="text-xs font-medium">ステータス</TableHead>
                    <TableHead className="text-xs font-medium">小計</TableHead>
                    <TableHead className="text-xs font-medium">合計</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-12"><Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
                  ) : !orders?.length ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-12">
                      <Truck className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">発注データがまだありません</p>
                    </TableCell></TableRow>
                  ) : orders.map((o: any) => {
                    const st = statusLabels[o.status] ?? statusLabels.draft;
                    return (
                      <TableRow key={o.id}>
                        <TableCell className="text-sm font-medium">{o.orderNumber}</TableCell>
                        <TableCell className="text-sm">{new Date(o.orderDate).toLocaleDateString("ja-JP")}</TableCell>
                        <TableCell><Badge variant="outline" className={`text-[10px] ${st.className}`}>{st.label}</Badge></TableCell>
                        <TableCell className="text-sm">{o.subtotal ? `¥${Number(o.subtotal).toLocaleString()}` : "—"}</TableCell>
                        <TableCell className="text-sm font-semibold">{o.totalAmount ? `¥${Number(o.totalAmount).toLocaleString()}` : "—"}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Cards - Mobile */}
          <div className="md:hidden space-y-2">
            {isLoading ? (
              <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : !orders?.length ? (
              <Card className="border shadow-none"><CardContent className="py-12 text-center">
                <Truck className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">発注データがまだありません</p>
              </CardContent></Card>
            ) : orders.map((o: any) => {
              const st = statusLabels[o.status] ?? statusLabels.draft;
              return (
                <Card key={o.id} className="border shadow-none">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <span className="text-sm font-medium">{o.orderNumber}</span>
                      <Badge variant="outline" className={`text-[10px] shrink-0 ${st.className}`}>{st.label}</Badge>
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>{new Date(o.orderDate).toLocaleDateString("ja-JP")}</span>
                      <span className="font-semibold text-foreground">{o.totalAmount ? `¥${Number(o.totalAmount).toLocaleString()}` : "—"}</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {/* Payment Schedule */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold tracking-tight flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            支払予定表
          </h2>
          <Card className="border shadow-none">
            <CardContent className="p-0">
              {!schedules?.length ? (
                <div className="p-6 text-center">
                  <Calendar className="h-8 w-8 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-xs text-muted-foreground">支払予定はありません</p>
                </div>
              ) : (
                <div className="divide-y">
                  {schedules.map((s: any) => (
                    <div key={s.id} className="px-4 py-3 flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium">{new Date(s.dueDate).toLocaleDateString("ja-JP")}</p>
                        <p className="text-xs text-muted-foreground">¥{Number(s.amount).toLocaleString()}</p>
                      </div>
                      <Badge variant="outline" className={`text-[10px] ${
                        s.status === "paid" ? "bg-emerald-50 text-emerald-700" :
                        s.status === "overdue" ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-700"
                      }`}>
                        {s.status === "paid" ? "支払済" : s.status === "overdue" ? "期日超過" : "予定"}
                      </Badge>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
