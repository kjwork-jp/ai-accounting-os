import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart3, TrendingUp, TrendingDown, Minus, Sparkles, Loader2, Lightbulb, ArrowUpRight, ArrowDownRight, RefreshCw } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend, Area, AreaChart } from "recharts";
import { Streamdown } from "streamdown";

const trendIcons: Record<string, any> = { up: ArrowUpRight, down: ArrowDownRight, flat: Minus };
const trendColors: Record<string, string> = { up: "text-emerald-600", down: "text-red-600", flat: "text-slate-500" };

export default function Analytics() {
  const [reportType, setReportType] = useState<"monthly_pl" | "account_trend" | "partner_analysis" | "cash_flow">("monthly_pl");
  const [report, setReport] = useState<any>(null);
  const generateMutation = trpc.analysis.generateReport.useMutation();

  const handleGenerate = async () => {
    try {
      toast.info("AIが分析レポートを生成中...");
      const result = await generateMutation.mutateAsync({ type: reportType });
      setReport(result);
      toast.success("レポートを生成しました");
    } catch { toast.error("生成に失敗しました"); }
  };

  const reportTypeLabels: Record<string, string> = {
    monthly_pl: "月次損益計算書",
    account_trend: "科目別推移分析",
    partner_analysis: "取引先別分析",
    cash_flow: "資金繰り予測",
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">経営分析</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">AIによる経営分析レポートと変動要因分析を行います</p>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3">
          <Select value={reportType} onValueChange={(v: any) => setReportType(v)}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="monthly_pl">月次損益計算書</SelectItem>
              <SelectItem value="account_trend">科目別推移分析</SelectItem>
              <SelectItem value="partner_analysis">取引先別分析</SelectItem>
              <SelectItem value="cash_flow">資金繰り予測</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={handleGenerate} disabled={generateMutation.isPending} className="gap-2 shadow-sm w-full sm:w-auto">
            {generateMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
            AI分析を実行
          </Button>
        </div>
      </div>

      {generateMutation.isPending && (
        <Card className="border-primary/20 bg-primary/[0.02]">
          <CardContent className="p-8 flex flex-col items-center gap-3">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm font-medium">AIが{reportTypeLabels[reportType]}を分析中...</p>
            <p className="text-xs text-muted-foreground">数秒お待ちください</p>
          </CardContent>
        </Card>
      )}

      {!report && !generateMutation.isPending && (
        <Card className="border-dashed">
          <CardContent className="p-8 sm:p-12 flex flex-col items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-primary/5 flex items-center justify-center">
              <BarChart3 className="h-8 w-8 text-primary/40" />
            </div>
            <div className="text-center">
              <p className="text-lg font-semibold">経営分析レポート</p>
              <p className="text-sm text-muted-foreground mt-1">レポート種別を選択し、「AI分析を実行」をクリックしてください</p>
            </div>
          </CardContent>
        </Card>
      )}

      {report && (
        <div className="space-y-6">
          {/* Report Header */}
          <Card className="bg-gradient-to-br from-primary/[0.03] to-primary/[0.08] border-primary/10">
            <CardContent className="p-3 sm:p-5">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div>
                  <Badge variant="secondary" className="text-[10px] mb-2 gap-1">
                    <Sparkles className="h-3 w-3" />AI生成レポート
                  </Badge>
                  <h2 className="text-xl font-bold tracking-tight">{report.title}</h2>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed max-w-2xl">{report.summary}</p>
                </div>
                <Button variant="outline" size="sm" onClick={handleGenerate} className="gap-1 text-xs shrink-0">
                  <RefreshCw className="h-3 w-3" />再生成
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Key Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {report.keyMetrics?.map((m: any, i: number) => {
              const TrendIcon = trendIcons[m.trend] ?? Minus;
              return (
                <Card key={i} className="border shadow-none">
                  <CardContent className="p-4">
                    <p className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{m.label}</p>
                    <p className="text-2xl font-bold tracking-tight mt-1">{m.value}</p>
                    <div className={`flex items-center gap-1 mt-1 ${trendColors[m.trend]}`}>
                      <TrendIcon className="h-3.5 w-3.5" />
                      <span className="text-xs font-medium">{m.change}</span>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Chart */}
          {report.chartData?.length > 0 && (
            <Card className="border shadow-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold">月次推移チャート</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-56 sm:h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={report.chartData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                      <defs>
                        <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="oklch(0.65 0.15 240)" stopOpacity={0.15} />
                          <stop offset="95%" stopColor="oklch(0.65 0.15 240)" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="oklch(0.65 0.15 155)" stopOpacity={0.15} />
                          <stop offset="95%" stopColor="oklch(0.65 0.15 155)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.9 0 0)" />
                      <XAxis dataKey="month" tick={{ fontSize: 11 }} stroke="oklch(0.7 0 0)" />
                      <YAxis tick={{ fontSize: 10 }} stroke="oklch(0.7 0 0)" tickFormatter={v => `${(v / 10000).toFixed(0)}万`} width={40} />
                      <Tooltip formatter={(v: number) => `¥${v.toLocaleString()}`} contentStyle={{ fontSize: 12, borderRadius: 8, border: "1px solid oklch(0.9 0 0)" }} />
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Area type="monotone" dataKey="revenue" name="売上" stroke="oklch(0.65 0.15 240)" fill="url(#colorRevenue)" strokeWidth={2} />
                      <Area type="monotone" dataKey="expense" name="費用" stroke="oklch(0.65 0.15 25)" fill="none" strokeWidth={2} strokeDasharray="5 5" />
                      <Area type="monotone" dataKey="profit" name="利益" stroke="oklch(0.65 0.15 155)" fill="url(#colorProfit)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* AI Insights */}
            <Card className="border shadow-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary" />
                  AI変動要因分析
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {report.insights?.map((insight: string, i: number) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      <div className="h-5 w-5 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
                        <span className="text-[10px] font-bold text-primary">{i + 1}</span>
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{insight}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recommendations */}
            <Card className="border shadow-none">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-semibold flex items-center gap-2">
                  <Lightbulb className="h-4 w-4 text-amber-500" />
                  改善提案
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {report.recommendations?.map((rec: string, i: number) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      <div className="h-5 w-5 rounded-full bg-amber-50 flex items-center justify-center shrink-0 mt-0.5">
                        <Lightbulb className="h-3 w-3 text-amber-500" />
                      </div>
                      <p className="text-muted-foreground leading-relaxed">{rec}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
}
