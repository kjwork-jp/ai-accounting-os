import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { BookOpen, Plus, CheckCircle2, Clock, XCircle, Loader2, Sparkles } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusMap: Record<string, { label: string; className: string }> = {
  draft: { label: "下書き", className: "bg-slate-50 text-slate-700 border-slate-200" },
  confirmed: { label: "確定", className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  cancelled: { label: "取消", className: "bg-red-50 text-red-700 border-red-200" },
};

export default function Journals() {
  const [filterStatus, setFilterStatus] = useState("all");
  const [createOpen, setCreateOpen] = useState(false);
  const { data: journals, isLoading, refetch } = trpc.journals.list.useQuery(
    filterStatus !== "all" ? { status: filterStatus } : undefined
  );
  const confirmMutation = trpc.journals.confirm.useMutation();
  const createMutation = trpc.journals.create.useMutation();

  const [form, setForm] = useState({
    entryDate: new Date().toISOString().split("T")[0],
    description: "",
    totalAmount: "",
    debitAccount: "", debitCode: "", debitAmount: "",
    creditAccount: "", creditCode: "", creditAmount: "",
  });

  const handleCreate = async () => {
    try {
      await createMutation.mutateAsync({
        entryDate: form.entryDate,
        description: form.description,
        totalAmount: form.debitAmount,
        lines: [
          { side: "debit" as const, accountCode: form.debitCode, accountName: form.debitAccount, amount: form.debitAmount },
          { side: "credit" as const, accountCode: form.creditCode, accountName: form.creditAccount, amount: form.creditAmount },
        ],
      });
      toast.success("仕訳を作成しました");
      setCreateOpen(false);
      refetch();
    } catch { toast.error("作成に失敗しました"); }
  };

  const handleConfirm = async (id: number) => {
    try {
      await confirmMutation.mutateAsync({ id });
      toast.success("仕訳を確定しました");
      refetch();
    } catch { toast.error("確定に失敗しました"); }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">仕訳帳</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">仕訳の一覧管理・確定処理を行います</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-sm w-full sm:w-auto"><Plus className="h-4 w-4" />仕訳作成</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] sm:max-w-lg">
            <DialogHeader><DialogTitle>新規仕訳作成</DialogTitle></DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><Label className="text-xs">日付</Label><Input type="date" value={form.entryDate} onChange={e => setForm(p => ({ ...p, entryDate: e.target.value }))} /></div>
                <div><Label className="text-xs">摘要</Label><Input value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="取引内容" /></div>
              </div>
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">借方</p>
                <div className="grid grid-cols-3 gap-2">
                  <Input placeholder="科目コード" value={form.debitCode} onChange={e => setForm(p => ({ ...p, debitCode: e.target.value }))} />
                  <Input placeholder="勘定科目" value={form.debitAccount} onChange={e => setForm(p => ({ ...p, debitAccount: e.target.value }))} />
                  <Input placeholder="金額" type="number" value={form.debitAmount} onChange={e => setForm(p => ({ ...p, debitAmount: e.target.value }))} />
                </div>
              </div>
              <div className="space-y-2">
                <p className="text-xs font-medium text-muted-foreground">貸方</p>
                <div className="grid grid-cols-3 gap-2">
                  <Input placeholder="科目コード" value={form.creditCode} onChange={e => setForm(p => ({ ...p, creditCode: e.target.value }))} />
                  <Input placeholder="勘定科目" value={form.creditAccount} onChange={e => setForm(p => ({ ...p, creditAccount: e.target.value }))} />
                  <Input placeholder="金額" type="number" value={form.creditAmount} onChange={e => setForm(p => ({ ...p, creditAmount: e.target.value }))} />
                </div>
              </div>
              <Button onClick={handleCreate} disabled={createMutation.isPending} className="w-full">
                {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                作成
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex items-center gap-3">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-36"><SelectValue placeholder="ステータス" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">すべて</SelectItem>
            <SelectItem value="draft">下書き</SelectItem>
            <SelectItem value="confirmed">確定</SelectItem>
            <SelectItem value="cancelled">取消</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table - Desktop */}
      <Card className="border shadow-none hidden md:block">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-xs font-medium">日付</TableHead>
                <TableHead className="text-xs font-medium">摘要</TableHead>
                <TableHead className="text-xs font-medium">金額</TableHead>
                <TableHead className="text-xs font-medium">ステータス</TableHead>
                <TableHead className="text-xs font-medium">AI</TableHead>
                <TableHead className="text-xs font-medium text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-12"><Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
              ) : !journals?.length ? (
                <TableRow><TableCell colSpan={6} className="text-center py-12">
                  <BookOpen className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">仕訳がまだありません</p>
                </TableCell></TableRow>
              ) : journals.map((j: any) => {
                const st = statusMap[j.status] ?? statusMap.draft;
                return (
                  <TableRow key={j.id} className="group">
                    <TableCell className="text-sm">{new Date(j.entryDate).toLocaleDateString("ja-JP")}</TableCell>
                    <TableCell className="text-sm max-w-[200px] truncate">{j.description || "—"}</TableCell>
                    <TableCell className="text-sm font-medium">{j.totalAmount ? `¥${Number(j.totalAmount).toLocaleString()}` : "—"}</TableCell>
                    <TableCell><Badge variant="outline" className={`text-[10px] ${st.className}`}>{st.label}</Badge></TableCell>
                    <TableCell>{j.aiGenerated ? <Sparkles className="h-3.5 w-3.5 text-primary" /> : "—"}</TableCell>
                    <TableCell className="text-right">
                      {j.status === "draft" && (
                        <Button variant="ghost" size="sm" className="h-7 text-xs gap-1 opacity-0 group-hover:opacity-100 transition-opacity" onClick={() => handleConfirm(j.id)}>
                          <CheckCircle2 className="h-3 w-3" />確定
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Cards - Mobile */}
      <div className="md:hidden space-y-2">
        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : !journals?.length ? (
          <Card className="border shadow-none"><CardContent className="py-12 text-center">
            <BookOpen className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">仕訳がまだありません</p>
          </CardContent></Card>
        ) : journals.map((j: any) => {
          const st = statusMap[j.status] ?? statusMap.draft;
          return (
            <Card key={j.id} className="border shadow-none">
              <CardContent className="p-3">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <p className="text-sm font-medium truncate">{j.description || "—"}</p>
                  <Badge variant="outline" className={`text-[10px] shrink-0 ${st.className}`}>{st.label}</Badge>
                </div>
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{new Date(j.entryDate).toLocaleDateString("ja-JP")}</span>
                  <span className="font-medium text-foreground">{j.totalAmount ? `¥${Number(j.totalAmount).toLocaleString()}` : "—"}</span>
                  <div className="flex items-center gap-2">
                    {j.aiGenerated && <Sparkles className="h-3 w-3 text-primary" />}
                    {j.status === "draft" && (
                      <Button variant="outline" size="sm" className="h-6 text-[10px] gap-1" onClick={() => handleConfirm(j.id)}>
                        <CheckCircle2 className="h-3 w-3" />確定
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
