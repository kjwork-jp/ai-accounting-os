import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { FileText, Plus, Loader2, Send, CheckCircle2, Clock, AlertCircle, Ban, CreditCard } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

const statusConfig: Record<string, { label: string; className: string; icon: any }> = {
  draft: { label: "下書き", className: "bg-slate-50 text-slate-700 border-slate-200", icon: Clock },
  issued: { label: "発行済", className: "bg-blue-50 text-blue-700 border-blue-200", icon: FileText },
  sent: { label: "送付済", className: "bg-indigo-50 text-indigo-700 border-indigo-200", icon: Send },
  paid: { label: "入金済", className: "bg-emerald-50 text-emerald-700 border-emerald-200", icon: CheckCircle2 },
  overdue: { label: "期日超過", className: "bg-red-50 text-red-700 border-red-200", icon: AlertCircle },
  cancelled: { label: "取消", className: "bg-gray-50 text-gray-700 border-gray-200", icon: Ban },
};

export default function Invoices() {
  const [tab, setTab] = useState("issued");
  const [createOpen, setCreateOpen] = useState(false);
  const { data: invoices, isLoading, refetch } = trpc.invoices.list.useQuery({ type: tab as "issued" | "received" });
  const createMutation = trpc.invoices.create.useMutation();

  const [form, setForm] = useState({
    invoiceNumber: "", invoiceType: "issued" as "issued" | "received",
    issueDate: new Date().toISOString().split("T")[0], dueDate: "",
    subtotal: "", taxAmount: "", totalAmount: "", registrationNumber: "",
  });

  const handleCreate = async () => {
    try {
      await createMutation.mutateAsync({
        invoiceNumber: form.invoiceNumber || `INV-${Date.now()}`,
        invoiceType: form.invoiceType,
        issueDate: form.issueDate,
        dueDate: form.dueDate || undefined,
        subtotal: form.subtotal || undefined,
        taxAmount: form.taxAmount || undefined,
        totalAmount: form.totalAmount || undefined,
        registrationNumber: form.registrationNumber || undefined,
      });
      toast.success("請求書を作成しました");
      setCreateOpen(false);
      refetch();
    } catch { toast.error("作成に失敗しました"); }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">請求書管理</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">適格請求書の作成・発行・受領管理を行います</p>
        </div>
        <Dialog open={createOpen} onOpenChange={setCreateOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-sm w-full sm:w-auto"><Plus className="h-4 w-4" />請求書作成</Button>
          </DialogTrigger>
          <DialogContent className="max-w-[95vw] sm:max-w-lg max-h-[85vh] overflow-y-auto">
            <DialogHeader><DialogTitle>新規請求書作成</DialogTitle></DialogHeader>
            <div className="space-y-3 pt-2">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <Label className="text-xs">種別</Label>
                  <Select value={form.invoiceType} onValueChange={(v: "issued" | "received") => setForm(p => ({ ...p, invoiceType: v }))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="issued">発行（売上）</SelectItem>
                      <SelectItem value="received">受領（仕入）</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-xs">請求書番号</Label><Input value={form.invoiceNumber} onChange={e => setForm(p => ({ ...p, invoiceNumber: e.target.value }))} placeholder="自動採番" /></div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div><Label className="text-xs">発行日</Label><Input type="date" value={form.issueDate} onChange={e => setForm(p => ({ ...p, issueDate: e.target.value }))} /></div>
                <div><Label className="text-xs">支払期日</Label><Input type="date" value={form.dueDate} onChange={e => setForm(p => ({ ...p, dueDate: e.target.value }))} /></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div><Label className="text-xs">税抜金額</Label><Input type="number" value={form.subtotal} onChange={e => setForm(p => ({ ...p, subtotal: e.target.value }))} /></div>
                <div><Label className="text-xs">消費税額</Label><Input type="number" value={form.taxAmount} onChange={e => setForm(p => ({ ...p, taxAmount: e.target.value }))} /></div>
                <div><Label className="text-xs">合計金額</Label><Input type="number" value={form.totalAmount} onChange={e => setForm(p => ({ ...p, totalAmount: e.target.value }))} /></div>
              </div>
              <div><Label className="text-xs">適格請求書登録番号</Label><Input value={form.registrationNumber} onChange={e => setForm(p => ({ ...p, registrationNumber: e.target.value }))} placeholder="T1234567890123" /></div>
              <Button onClick={handleCreate} disabled={createMutation.isPending} className="w-full">
                {createMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}作成
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Invoice Compliance Card */}
      <Card className="border-primary/10 bg-gradient-to-r from-primary/[0.02] to-transparent">
        <CardContent className="p-3 sm:p-4 flex items-center gap-3">
          <div className="h-9 w-9 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
            <CheckCircle2 className="h-4.5 w-4.5 text-primary" />
          </div>
          <div>
            <p className="text-sm font-semibold">インボイス制度対応</p>
            <p className="text-xs text-muted-foreground">適格請求書の必須項目チェック・帳簿要件の自動検証を実施しています</p>
          </div>
        </CardContent>
      </Card>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="issued" className="gap-1.5 text-xs"><Send className="h-3.5 w-3.5" />発行請求書</TabsTrigger>
          <TabsTrigger value="received" className="gap-1.5 text-xs"><CreditCard className="h-3.5 w-3.5" />受領請求書</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4">
          {/* Table - Desktop */}
          <Card className="border shadow-none hidden md:block">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-xs font-medium">請求書番号</TableHead>
                    <TableHead className="text-xs font-medium">発行日</TableHead>
                    <TableHead className="text-xs font-medium">支払期日</TableHead>
                    <TableHead className="text-xs font-medium">ステータス</TableHead>
                    <TableHead className="text-xs font-medium">合計金額</TableHead>
                    <TableHead className="text-xs font-medium">登録番号</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {isLoading ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-12"><Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
                  ) : !invoices?.length ? (
                    <TableRow><TableCell colSpan={6} className="text-center py-12">
                      <FileText className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                      <p className="text-sm text-muted-foreground">{tab === "issued" ? "発行" : "受領"}請求書がまだありません</p>
                    </TableCell></TableRow>
                  ) : invoices.map((inv: any) => {
                    const st = statusConfig[inv.status] ?? statusConfig.draft;
                    const StIcon = st.icon;
                    return (
                      <TableRow key={inv.id}>
                        <TableCell className="text-sm font-medium">{inv.invoiceNumber}</TableCell>
                        <TableCell className="text-sm">{new Date(inv.issueDate).toLocaleDateString("ja-JP")}</TableCell>
                        <TableCell className="text-sm">{inv.dueDate ? new Date(inv.dueDate).toLocaleDateString("ja-JP") : "—"}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className={`text-[10px] gap-1 ${st.className}`}>
                            <StIcon className="h-3 w-3" />{st.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm font-semibold">{inv.totalAmount ? `¥${Number(inv.totalAmount).toLocaleString()}` : "—"}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{inv.registrationNumber || "—"}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Cards - Mobile */}
          <div className="md:hidden space-y-2">
            {isLoading ? (
              <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : !invoices?.length ? (
              <Card className="border shadow-none"><CardContent className="py-12 text-center">
                <FileText className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                <p className="text-sm text-muted-foreground">{tab === "issued" ? "発行" : "受領"}請求書がまだありません</p>
              </CardContent></Card>
            ) : invoices.map((inv: any) => {
              const st = statusConfig[inv.status] ?? statusConfig.draft;
              const StIcon = st.icon;
              return (
                <Card key={inv.id} className="border shadow-none">
                  <CardContent className="p-3">
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <span className="text-sm font-medium">{inv.invoiceNumber}</span>
                      <Badge variant="outline" className={`text-[10px] gap-1 shrink-0 ${st.className}`}>
                        <StIcon className="h-3 w-3" />{st.label}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-1">
                      <span>{new Date(inv.issueDate).toLocaleDateString("ja-JP")}</span>
                      <span className="font-semibold text-foreground">{inv.totalAmount ? `¥${Number(inv.totalAmount).toLocaleString()}` : "—"}</span>
                    </div>
                    {inv.registrationNumber && (
                      <p className="text-[10px] text-muted-foreground">登録番号: {inv.registrationNumber}</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
