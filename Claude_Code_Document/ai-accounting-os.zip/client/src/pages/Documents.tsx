import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Upload, FileText, Search, Sparkles, Eye, Loader2, CheckCircle2, AlertCircle, Clock, XCircle } from "lucide-react";
import { useState, useCallback } from "react";
import { toast } from "sonner";

const docTypeLabels: Record<string, string> = {
  invoice: "請求書", receipt: "領収書", delivery_note: "納品書", quotation: "見積書",
  contract: "契約書", bank_statement: "銀行明細", credit_card: "クレカ明細", other: "その他",
};

const statusConfig: Record<string, { label: string; icon: any; className: string }> = {
  uploaded: { label: "アップロード済", icon: Clock, className: "bg-slate-50 text-slate-700 border-slate-200" },
  processing: { label: "解析中", icon: Loader2, className: "bg-blue-50 text-blue-700 border-blue-200" },
  extracted: { label: "抽出完了", icon: CheckCircle2, className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  verified: { label: "検証済", icon: CheckCircle2, className: "bg-green-50 text-green-700 border-green-200" },
  error: { label: "エラー", icon: XCircle, className: "bg-red-50 text-red-700 border-red-200" },
};

export default function Documents() {
  const [uploadOpen, setUploadOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<any>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const { data: documents, isLoading, refetch } = trpc.documents.list.useQuery(
    filterStatus !== "all" ? { status: filterStatus } : undefined
  );
  const uploadMutation = trpc.documents.upload.useMutation();
  const analyzeMutation = trpc.documents.analyze.useMutation();
  const { data: suggestions } = trpc.documents.getSuggestions.useQuery(
    { documentId: selectedDoc?.id ?? 0 },
    { enabled: !!selectedDoc?.id }
  );

  const handleFileUpload = useCallback(async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(",")[1];
      try {
        const result = await uploadMutation.mutateAsync({
          fileName: file.name,
          fileData: base64,
          mimeType: file.type,
          fileSize: file.size,
        });
        toast.success("証憑をアップロードしました");
        setUploadOpen(false);
        refetch();
      } catch (err) {
        toast.error("アップロードに失敗しました");
      }
    };
    reader.readAsDataURL(file);
  }, [uploadMutation, refetch]);

  const handleAnalyze = async (docId: number) => {
    try {
      toast.info("AIが証憑を解析中です...");
      await analyzeMutation.mutateAsync({ id: docId });
      toast.success("AI解析が完了しました");
      refetch();
    } catch (err) {
      toast.error("AI解析に失敗しました");
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">証憑管理</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">請求書・領収書等の証憑をアップロードし、AIで自動解析します</p>
        </div>
        <Dialog open={uploadOpen} onOpenChange={setUploadOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2 shadow-sm w-full sm:w-auto">
              <Upload className="h-4 w-4" />
              証憑アップロード
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>証憑をアップロード</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 pt-2">
              <div className="border-2 border-dashed rounded-xl p-8 text-center hover:border-primary/40 transition-colors">
                <Upload className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm font-medium mb-1">ファイルをドラッグ＆ドロップ</p>
                <p className="text-xs text-muted-foreground mb-3">PDF, JPG, PNG 対応</p>
                <label>
                  <input type="file" accept=".pdf,.jpg,.jpeg,.png" className="hidden" onChange={handleFileUpload} />
                  <Button variant="outline" size="sm" asChild>
                    <span>ファイルを選択</span>
                  </Button>
                </label>
              </div>
              {uploadMutation.isPending && (
                <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  アップロード中...
                </div>
              )}
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3">
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="ステータス" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">すべて</SelectItem>
            <SelectItem value="uploaded">アップロード済</SelectItem>
            <SelectItem value="processing">解析中</SelectItem>
            <SelectItem value="extracted">抽出完了</SelectItem>
            <SelectItem value="verified">検証済</SelectItem>
            <SelectItem value="error">エラー</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Documents Table - Desktop */}
      <Card className="border shadow-none hidden md:block">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-xs font-medium">ファイル名</TableHead>
                <TableHead className="text-xs font-medium">種別</TableHead>
                <TableHead className="text-xs font-medium">ステータス</TableHead>
                <TableHead className="text-xs font-medium">金額</TableHead>
                <TableHead className="text-xs font-medium">信頼度</TableHead>
                <TableHead className="text-xs font-medium">日時</TableHead>
                <TableHead className="text-xs font-medium text-right">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12">
                    <Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" />
                  </TableCell>
                </TableRow>
              ) : !documents?.length ? (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-12">
                    <FileText className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">証憑がまだありません</p>
                    <p className="text-xs text-muted-foreground/60 mt-1">「証憑アップロード」から追加してください</p>
                  </TableCell>
                </TableRow>
              ) : (
                documents.map((doc: any) => {
                  const status = statusConfig[doc.status] ?? statusConfig.uploaded;
                  const StatusIcon = status.icon;
                  return (
                    <TableRow key={doc.id} className="group">
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <FileText className="h-4 w-4 text-muted-foreground/60" />
                          <span className="text-sm font-medium truncate max-w-[200px]">{doc.fileName}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="text-xs">{docTypeLabels[doc.documentType] ?? doc.documentType}</span>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className={`text-[10px] gap-1 ${status.className}`}>
                          <StatusIcon className={`h-3 w-3 ${doc.status === "processing" ? "animate-spin" : ""}`} />
                          {status.label}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm">
                        {doc.amount ? `¥${Number(doc.amount).toLocaleString()}` : "—"}
                      </TableCell>
                      <TableCell>
                        {doc.aiConfidence ? (
                          <div className="flex items-center gap-1.5">
                            <div className="h-1.5 w-12 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${Number(doc.aiConfidence) >= 0.9 ? "bg-emerald-500" : Number(doc.aiConfidence) >= 0.7 ? "bg-amber-500" : "bg-red-500"}`}
                                style={{ width: `${Number(doc.aiConfidence) * 100}%` }}
                              />
                            </div>
                            <span className="text-[10px] text-muted-foreground">{(Number(doc.aiConfidence) * 100).toFixed(0)}%</span>
                          </div>
                        ) : "—"}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {new Date(doc.createdAt).toLocaleDateString("ja-JP")}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                          {doc.status === "uploaded" && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 text-xs gap-1"
                              onClick={() => handleAnalyze(doc.id)}
                              disabled={analyzeMutation.isPending}
                            >
                              <Sparkles className="h-3 w-3" />
                              AI解析
                            </Button>
                          )}
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-7 text-xs gap-1"
                            onClick={() => { setSelectedDoc(doc); setDetailOpen(true); }}
                          >
                            <Eye className="h-3 w-3" />
                            詳細
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Documents Cards - Mobile */}
      <div className="md:hidden space-y-2">
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : !documents?.length ? (
          <Card className="border shadow-none">
            <CardContent className="py-12 text-center">
              <FileText className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">証憑がまだありません</p>
            </CardContent>
          </Card>
        ) : (
          documents.map((doc: any) => {
            const status = statusConfig[doc.status] ?? statusConfig.uploaded;
            const StatusIcon = status.icon;
            return (
              <Card key={doc.id} className="border shadow-none">
                <CardContent className="p-3">
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileText className="h-4 w-4 text-muted-foreground/60 shrink-0" />
                      <span className="text-sm font-medium truncate">{doc.fileName}</span>
                    </div>
                    <Badge variant="outline" className={`text-[10px] gap-1 shrink-0 ${status.className}`}>
                      <StatusIcon className={`h-3 w-3 ${doc.status === "processing" ? "animate-spin" : ""}`} />
                      {status.label}
                    </Badge>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{docTypeLabels[doc.documentType] ?? doc.documentType}</span>
                    <span>{doc.amount ? `¥${Number(doc.amount).toLocaleString()}` : "—"}</span>
                    <span>{new Date(doc.createdAt).toLocaleDateString("ja-JP")}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    {doc.status === "uploaded" && (
                      <Button variant="outline" size="sm" className="h-7 text-xs gap-1 flex-1" onClick={() => handleAnalyze(doc.id)} disabled={analyzeMutation.isPending}>
                        <Sparkles className="h-3 w-3" /> AI解析
                      </Button>
                    )}
                    <Button variant="outline" size="sm" className="h-7 text-xs gap-1 flex-1" onClick={() => { setSelectedDoc(doc); setDetailOpen(true); }}>
                      <Eye className="h-3 w-3" /> 詳細
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              証憑詳細
            </DialogTitle>
          </DialogHeader>
          {selectedDoc && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 sm:gap-4 text-sm">
                <div><span className="text-muted-foreground">ファイル名:</span> <span className="font-medium">{selectedDoc.fileName}</span></div>
                <div><span className="text-muted-foreground">種別:</span> <span className="font-medium">{docTypeLabels[selectedDoc.documentType]}</span></div>
                <div><span className="text-muted-foreground">金額:</span> <span className="font-medium">{selectedDoc.amount ? `¥${Number(selectedDoc.amount).toLocaleString()}` : "—"}</span></div>
                <div><span className="text-muted-foreground">税額:</span> <span className="font-medium">{selectedDoc.taxAmount ? `¥${Number(selectedDoc.taxAmount).toLocaleString()}` : "—"}</span></div>
                <div><span className="text-muted-foreground">税率:</span> <span className="font-medium">{selectedDoc.taxRate ?? "—"}</span></div>
                <div><span className="text-muted-foreground">登録番号:</span> <span className="font-medium">{selectedDoc.registrationNumber ?? "—"}</span></div>
              </div>

              {suggestions && suggestions.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold flex items-center gap-2">
                    <Sparkles className="h-4 w-4 text-primary" />
                    AI仕訳候補 Top3
                  </h3>
                  {suggestions.map((s: any, i: number) => (
                    <Card key={s.id} className={`border ${i === 0 ? "border-primary/30 bg-primary/[0.02]" : ""}`}>
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant={i === 0 ? "default" : "outline"} className="text-[10px]">
                            候補 {s.rank}
                          </Badge>
                          <span className={`text-xs font-medium ${Number(s.confidence) >= 0.9 ? "text-emerald-600" : Number(s.confidence) >= 0.7 ? "text-amber-600" : "text-red-600"}`}>
                            信頼度 {(Number(s.confidence) * 100).toFixed(0)}%
                          </span>
                        </div>
                        <div className="text-xs space-y-1">
                          <p><span className="text-muted-foreground">借方:</span> {s.suggestion?.debitAccount} ({s.suggestion?.debitAccountCode})</p>
                          <p><span className="text-muted-foreground">貸方:</span> {s.suggestion?.creditAccount} ({s.suggestion?.creditAccountCode})</p>
                          <p><span className="text-muted-foreground">税区分:</span> {s.suggestion?.taxCategory}</p>
                          <p className="text-muted-foreground italic mt-1">{s.reason}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
