import { trpc } from "@/lib/trpc";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Shield, Loader2, Sparkles, User, FileText, BookOpen, CheckSquare, Users, Eye } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

const actionLabels: Record<string, { label: string; className: string }> = {
  create: { label: "作成", className: "bg-blue-50 text-blue-700 border-blue-200" },
  update: { label: "更新", className: "bg-cyan-50 text-cyan-700 border-cyan-200" },
  upload: { label: "アップロード", className: "bg-indigo-50 text-indigo-700 border-indigo-200" },
  ai_analyze: { label: "AI解析", className: "bg-violet-50 text-violet-700 border-violet-200" },
  confirm: { label: "確定", className: "bg-emerald-50 text-emerald-700 border-emerald-200" },
  approve: { label: "承認", className: "bg-green-50 text-green-700 border-green-200" },
  reject: { label: "却下", className: "bg-red-50 text-red-700 border-red-200" },
  return: { label: "差戻", className: "bg-orange-50 text-orange-700 border-orange-200" },
};

const entityIcons: Record<string, any> = {
  document: FileText, journal: BookOpen, approval: CheckSquare, partner: Users, invoice: FileText, order: FileText,
};

export default function AuditLogs() {
  const [filterAction, setFilterAction] = useState("all");
  const [filterEntity, setFilterEntity] = useState("all");
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedLog, setSelectedLog] = useState<any>(null);

  const { data: logs, isLoading } = trpc.auditLogs.list.useQuery(
    {
      ...(filterAction !== "all" ? { action: filterAction } : {}),
      ...(filterEntity !== "all" ? { entityType: filterEntity } : {}),
    }
  );

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">監査ログ</h1>
          <p className="text-xs sm:text-sm text-muted-foreground mt-1">全操作履歴とAI判断ログの記録・検索を行います</p>
        </div>
        <Badge variant="outline" className="text-xs gap-1 border-emerald-200 text-emerald-700 bg-emerald-50 self-start sm:self-auto">
          <Shield className="h-3 w-3" />
          全操作記録中
        </Badge>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3">
        <Select value={filterAction} onValueChange={setFilterAction}>
          <SelectTrigger className="w-full sm:w-36"><SelectValue placeholder="アクション" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">すべて</SelectItem>
            <SelectItem value="create">作成</SelectItem>
            <SelectItem value="update">更新</SelectItem>
            <SelectItem value="upload">アップロード</SelectItem>
            <SelectItem value="ai_analyze">AI解析</SelectItem>
            <SelectItem value="confirm">確定</SelectItem>
            <SelectItem value="approve">承認</SelectItem>
            <SelectItem value="reject">却下</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterEntity} onValueChange={setFilterEntity}>
          <SelectTrigger className="w-full sm:w-36"><SelectValue placeholder="エンティティ" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">すべて</SelectItem>
            <SelectItem value="document">証憑</SelectItem>
            <SelectItem value="journal">仕訳</SelectItem>
            <SelectItem value="approval">決裁</SelectItem>
            <SelectItem value="partner">取引先</SelectItem>
            <SelectItem value="invoice">請求書</SelectItem>
            <SelectItem value="order">受発注</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Table - Desktop */}
      <Card className="border shadow-none hidden md:block">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="text-xs font-medium">日時</TableHead>
                <TableHead className="text-xs font-medium">アクション</TableHead>
                <TableHead className="text-xs font-medium">対象</TableHead>
                <TableHead className="text-xs font-medium">ユーザー</TableHead>
                <TableHead className="text-xs font-medium">AI信頼度</TableHead>
                <TableHead className="text-xs font-medium text-right">詳細</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                <TableRow><TableCell colSpan={6} className="text-center py-12"><Loader2 className="h-5 w-5 animate-spin mx-auto text-muted-foreground" /></TableCell></TableRow>
              ) : !logs?.length ? (
                <TableRow><TableCell colSpan={6} className="text-center py-12">
                  <Shield className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
                  <p className="text-sm text-muted-foreground">監査ログがまだありません</p>
                </TableCell></TableRow>
              ) : logs.map((log: any) => {
                const action = actionLabels[log.action] ?? { label: log.action, className: "bg-slate-50 text-slate-700 border-slate-200" };
                const EntityIcon = entityIcons[log.entityType] ?? FileText;
                return (
                  <TableRow key={log.id} className="group">
                    <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
                      {new Date(log.createdAt).toLocaleString("ja-JP", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" })}
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className={`text-[10px] ${action.className}`}>
                        {log.action === "ai_analyze" && <Sparkles className="h-3 w-3 mr-0.5" />}
                        {action.label}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <EntityIcon className="h-3.5 w-3.5 text-muted-foreground/50" />
                        <span className="text-xs">{log.entityType}</span>
                        {log.entityId && <span className="text-[10px] text-muted-foreground">#{log.entityId}</span>}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <div className="h-5 w-5 rounded-full bg-muted/50 flex items-center justify-center">
                          <User className="h-3 w-3 text-muted-foreground/60" />
                        </div>
                        <span className="text-xs">{log.userName || "System"}</span>
                      </div>
                    </TableCell>
                    <TableCell>
                      {log.aiConfidence ? (
                        <div className="flex items-center gap-1.5">
                          <Sparkles className="h-3 w-3 text-primary" />
                          <span className="text-xs font-medium">{(Number(log.aiConfidence) * 100).toFixed(0)}%</span>
                        </div>
                      ) : "—"}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost" size="sm"
                        className="h-7 text-xs gap-1 opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => { setSelectedLog(log); setDetailOpen(true); }}
                      >
                        <Eye className="h-3 w-3" />詳細
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Cards - Mobile */}
      <div className="md:hidden space-y-2">
        {isLoading ? (
          <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : !logs?.length ? (
          <Card className="border shadow-none"><CardContent className="py-12 text-center">
            <Shield className="h-10 w-10 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-sm text-muted-foreground">監査ログがまだありません</p>
          </CardContent></Card>
        ) : logs.map((log: any) => {
          const action = actionLabels[log.action] ?? { label: log.action, className: "bg-slate-50 text-slate-700 border-slate-200" };
          const EntityIcon = entityIcons[log.entityType] ?? FileText;
          return (
            <Card key={log.id} className="border shadow-none" onClick={() => { setSelectedLog(log); setDetailOpen(true); }}>
              <CardContent className="p-3 cursor-pointer active:bg-muted/30 transition-colors">
                <div className="flex items-start justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Badge variant="outline" className={`text-[10px] ${action.className}`}>
                      {log.action === "ai_analyze" && <Sparkles className="h-3 w-3 mr-0.5" />}
                      {action.label}
                    </Badge>
                    <div className="flex items-center gap-1">
                      <EntityIcon className="h-3 w-3 text-muted-foreground/50" />
                      <span className="text-[10px] text-muted-foreground">{log.entityType}{log.entityId ? ` #${log.entityId}` : ""}</span>
                    </div>
                  </div>
                  {log.aiConfidence && (
                    <div className="flex items-center gap-1 shrink-0">
                      <Sparkles className="h-3 w-3 text-primary" />
                      <span className="text-[10px] font-medium">{(Number(log.aiConfidence) * 100).toFixed(0)}%</span>
                    </div>
                  )}
                </div>
                <div className="flex items-center justify-between text-[10px] text-muted-foreground">
                  <span>{log.userName || "System"}</span>
                  <span>{new Date(log.createdAt).toLocaleString("ja-JP", { month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" })}</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-[95vw] sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              監査ログ詳細
            </DialogTitle>
          </DialogHeader>
          {selectedLog && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><span className="text-muted-foreground text-xs">アクション:</span><p className="font-medium">{actionLabels[selectedLog.action]?.label ?? selectedLog.action}</p></div>
                <div><span className="text-muted-foreground text-xs">対象:</span><p className="font-medium">{selectedLog.entityType} #{selectedLog.entityId}</p></div>
                <div><span className="text-muted-foreground text-xs">ユーザー:</span><p className="font-medium">{selectedLog.userName || "System"}</p></div>
                <div><span className="text-muted-foreground text-xs">日時:</span><p className="font-medium">{new Date(selectedLog.createdAt).toLocaleString("ja-JP")}</p></div>
              </div>
              {selectedLog.details && (
                <div>
                  <span className="text-muted-foreground text-xs">詳細データ:</span>
                  <pre className="mt-1 p-3 bg-muted/30 rounded-lg text-xs overflow-auto max-h-40 font-mono">
                    {JSON.stringify(selectedLog.details, null, 2)}
                  </pre>
                </div>
              )}
              {selectedLog.aiOutput && (
                <div>
                  <span className="text-muted-foreground text-xs flex items-center gap-1"><Sparkles className="h-3 w-3 text-primary" />AI出力:</span>
                  <pre className="mt-1 p-3 bg-primary/5 rounded-lg text-xs overflow-auto max-h-40 font-mono">
                    {JSON.stringify(selectedLog.aiOutput, null, 2)}
                  </pre>
                </div>
              )}
              {selectedLog.ipAddress && (
                <div><span className="text-muted-foreground text-xs">IPアドレス:</span><p className="font-mono text-xs">{selectedLog.ipAddress}</p></div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
